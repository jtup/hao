<?php
require_once(APPDIR.'/include/global.inc.php');

/**
 * ��ʼ����վ������Ϣ
 */
function init_config(){
	global $config, $safe_domains, $block_domains, $block_javascript, $address;
	//Ϊ��ǰ������վ����һ��Ψһ�Ĳ���Ķ���id
	$key = !empty($config['encrypt_seed']) ? $config['encrypt_seed'] : $_SERVER['SERVER_NAME'];
	$siteid = strtr(md5($key), '0123456789', 'qrstuvwxyz');
	$siteid = implode(array_unique(str_split($siteid,1)));
	if(strlen($siteid)<10) $siteid.=substr('ghijklmnop',0,10-strlen($siteid));
	$encryptKey = substr($siteid,0,5);

	$config = array(
		'siteid' => $siteid,
		//����ǰ���ݡ���һ������㷨�ı���ܳ�
		'encrypt_keys' => array($encryptKey.strtoupper($encryptKey).'+/', strtoupper($encryptKey).$encryptKey.'_-'),
		//�ڶ�������㷨�������ܳ�
		'encrypt2_key' => base_convert_62(abs(crc32($key)),10,62,2),
		//��ַ������
		'url_var_name' => substr($siteid,0,3),
		//url�������β��׷����Դ��ʶ�Ĳ������ƣ�������һ���»��߿�ͷ
		'ctype_var_name' => '_'.substr($siteid,1,3),
		//·����������javascript����ֵ���ַֻ�ܽ���������, javascript����֮���������Ϊ·�����䣩����Ҫʹ��id,
		'url_path_name' => '_'.substr($siteid,2,3),
		//��ֹ���ʵ���ַ������
		'block_var_name' => '_'.substr($siteid,3,3),
		//��ҳ��֤������
		'basic_auth_var_name' => '_'.substr($siteid,0,4),
		//���ڼ�������cookie�ı�����
		'cookie_counter' => '_'.substr($siteid,1,4),
		//�ͻ������ڿ����Ƿ���ʾ�ײ���������cookie�ı�����
		'cookie_bottom_navigation' => '_'.substr($siteid,2,4),
		//һЩ���ö����Ĳ�����
		'built_in_name' => '_'.substr($siteid,3,4),
		//��������ύ��ַ�������������
		'get_form_name' => '_'.substr($siteid,4,4),
		//���ܺ�����
		'js_func' => '_'.substr($siteid,0,5),

		//�Ƿ�֧��.htaccess�ļ�
		'enable_rewrite' => isset($_SERVER['HTTP_X_USEING_HTACCESS']),
		//url�������β��׷����Դ��ʶ�ķ�ʽ��[1]��ʹ��α��̬ʱ���� &ctype={ctype} ��ʽ׷�ӣ�[2]α��̬����ַ���� {ctype}/ ��ʽ׷�ӣ�[0]������׷��
		'ctype_mode' => !isset($_SERVER['HTTP_X_USEING_HTACCESS']) ? 1 : ($config['enable_shorturl']?2:0),
		//�Ƿ�֧��ssl
		'enable_ssl' => extension_loaded ( 'openssl' ) && version_compare ( PHP_VERSION, '4.3.0', '>=' ),
		//magic_quotes_gpc
		'stripslashes' => get_magic_quotes_gpc(),
		//��Զ�˷�����֮������ݴ����Ƿ����zlibѹ����ʽ�����ػ������Ǳ����ѹ������ݣ�
		'zlib_remote' => extension_loaded("zlib") && (function_exists('gzdecode') || function_exists('gzinflate')),
		//�Ƿ����ѹ�����ݣ�0��ѹ�� 1�Զ�ѹ�� 2�ô���ѹ��
		'zlib_output' => extension_loaded("zlib") && function_exists('gzencode') && isset($_SERVER["HTTP_ACCEPT_ENCODING"])
			? (preg_match('/(on|[1-9])/i',ini_get('zlib.output_compression')) && preg_match('/-?[1-9]/',ini_get('zlib.output_compression_level')) ? 1 : 2)
			: 0,
		//���pcre�İ汾��ȷ������������������ʽ��ʽ
		'pcre_old' => preg_match('#^[1-6][\.\s]#',constant('PCRE_VERSION')),

		//����ҳ��ʼ����ֵ����ʾ�ı������������������Ϣ
		'cache_salt_for_supported' => null,
		//cdn���Ĵ���������ﵽ�����󣬾ʹ��¼���µ�cdn
		'max_cdn_fail' => 3,
	) + $config;

	//ǿ�ƹر�������
 	$config['allowed_spider']='';
 	$config['simple_for_mobile']=false;

	if(!isset($config['plugin'])) $config['plugin']='';
	if(!isset($config['cdn_servers'])) $config['cdn_servers']='';
	if(!isset($config['cdn_select_count'])) $config['cdn_select_count']=5;
	if(!isset($config['reserve_ad'])) $config['reserve_ad']=false;
	if(!isset($config['reserve_unknown_domain'])) $config['reserve_unknown_domain']=false;
	if(!isset($config['player_only_allow_cn'])) $config['player_only_allow_cn']=false;
	if(!isset($config['enable_og'])) $config['enable_og']=false;
	if(empty($config['encrypt_seed'])) $config['cdn_servers']='';

	if(!isset($_SERVER["OLD_REQUEST_SCHEME"])){
		$_SERVER["OLD_REQUEST_SCHEME"] = Url::getCurrentScheme();
		$_SERVER['OLD_HTTP_HOST'] = Url::getCurrentSite();
	}

	//gae
	if(isset($_SERVER['APPLICATION_ID'], $_SERVER['HTTP_X_APPENGINE_COUNTRY'])){
		$_SERVER['IS_GAE'] = 1;
		$_SERVER['PHP_SELF'] = '/index.php';
		$config['enable_rewrite'] = 1;
		$config['http_function'] = 'fopen';
		$config['enable_shorturl'] = $config['enable_cache'] = false;
	}

	//cloudflare
	if(!empty($_SERVER["HTTP_CF_VISITOR"])){
	    if(strpos($_SERVER["HTTP_CF_VISITOR"],'"https"')>0){
	        $_SERVER["REQUEST_SCHEME"] = 'https';
	    }
	}

	//����ǰ������
	init_frontend_host_config();

	//ǰ����atsʱ���ÿ͵�ʵ��ip��HTTP_CLIENT_IP��ֵ����ʱ��REMOTE_ADDRʵ������ǰ�˵�ats�������ĵ�ַ
	if(isset($_SERVER['HTTP_CLIENT_IP']) && isset($_SERVER['HTTP_VIA']) && strpos($_SERVER['HTTP_VIA'],'ApacheTrafficServer')!==false){
		$_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CLIENT_IP'];
	}

	//�����Ƿ��������룬�޸�common��ļ����б�
	if($config['reserve_ad']){
	    if(!empty($block_domains['ad'])) $safe_domains = array_merge($safe_domains, $block_domains['ad']);
	    unset($block_domains['ad'], $block_javascript['ad']);
	}

	if(empty($config['mirror_site'])){
        $config['mirror_site']=null;
        $config['mirror_agents']=null;
        $config['mirror_sensitive_words']=null;
	}

	//��/data/address.dat��������$address�б�
	if(file_exists(DATADIR.'/address.dat')){
	    $lines = file(DATADIR.'/address.dat');
	    foreach($lines as $line){
	        $record = explode('|', rtrim($line));
	        if(count($record)==3 && !isset($address[$record[0]])){
	            $address[$record[0]] = "{$record[1]}|{$record[2]}";
	        }
	    }
	}
}

function init_frontend_host_config(){
    global $config;
    //ָ����վ�ķ�������������Ͷ˿ڣ�ǰ����ʾ���û��������Ͷ˿ڣ�
    if(!empty($config['frontend_host'])){
        $s = $config['frontend_host'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_HOST'])){
        $s = $_SERVER['HTTP_X_FORWARDED_HOST'];
    }else{
        $s = '';
    }
    if($s && preg_match('#^(?:(https?)://)?([\w\-\.]+)(?::(\d+))?(?:/|$)#', $s, $match)){
        $scheme = $match[1];
        if(empty($scheme)){
        	$scheme = Url::getCurrentScheme();
        }
        $is_https = $scheme=='https';

        $server = $match[2];
        $port = empty($match[3]) ? '' : $match[3];
        if(!$port){
            $port = $is_https ? 443 : 80;
            $host = $server;
        }elseif(($is_https && $port==443) || (!$is_https && $port==80)){
            $host = $server;
        }else{
            $host = "{$server}:{$port}";
        }

        $_SERVER["REQUEST_SCHEME"] = $scheme;
        $_SERVER['HTTP_HOST'] = $host;
    }
    $config['frontend_host_inited'] = true;
}

/**
 * error handler function
 */
function myErrorHandler($errno, $errstr, $errfile, $errline)
{
	//$b = error_reporting() & $errno;
	if ($errno>=E_STRICT) return true;
	$isFaultError = in_array($errno, array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR));
	if(DEBUGING || $isFaultError){
		$errorTypes = array (
			E_ERROR          => 'ERROR',
			E_WARNING        => 'WARNING',
			E_PARSE          => 'PARSING ERROR',
			E_NOTICE         => 'NOTICE',
			E_CORE_ERROR     => 'CORE ERROR',
			E_CORE_WARNING   => 'CORE WARNING',
			E_COMPILE_ERROR  => 'COMPILE ERROR',
			E_COMPILE_WARNING => 'COMPILE WARNING',
			E_USER_ERROR     => 'USER ERROR',
			E_USER_WARNING   => 'USER WARNING',
			E_USER_NOTICE    => 'USER NOTICE',
			E_STRICT         => 'STRICT NOTICE',
			E_RECOVERABLE_ERROR  => 'RECOVERABLE ERROR'
		);

		static $errorRaised = 0;
		$data = '';

		if($errorRaised==0){
			$errorRaised++;
			$data .= "\r\n".date('Y-m-d H:i:s')."\r\n";
		}
		if($errorRaised==1 && isset($GLOBALS['currentUrl'])){
			$errorRaised++;
			$data .= "current_url: {$GLOBALS['currentUrl']->original}\r\n";
		}
		if($errorRaised==2 && isset($GLOBALS['remoteUrl'])){
			$errorRaised++;
			$data .= "remote_url: {$GLOBALS['remoteUrl']->original}\r\n";
		}

		$errfile = substr($errfile, strlen(APPDIR));
		$data .= "{$errorTypes[$errno]}, {$errstr}, FILE: {$errfile} LINE: {$errline}\r\n";
		$arr = debug_backtrace();
		if(isset($arr[0]['function']) && $arr[0]['function']=='myErrorHandler') unset($arr[0]);
		foreach($arr as $k=>$v){
			if($k>3) break;
			$line = '';
			if(isset($v['file'])) $line .= substr($v['file'], strlen(APPDIR))." ({$v['line']}), ";
			$line .= "{$v['function']}( ";
			if(isset($v['args'])){
				foreach($v['args'] as $v){
					if(is_scalar($v)) {
						$v = strtr($v, "\r\n\t","   ");
						$line .= strlen($v)<=100 ? $v : substr($v,0,100);
					}else{
						$line .= "[".gettype($v)."]";
					}
					$line .= ", ";
				}
			}
			$line = trim($line, ", ")." )";
			$data .= "\t{$line}\r\n";
		}

		if(empty($_SERVER['IS_GAE'])) {
			@file_put_contents(TEMPDIR.'/~errors_'.date('Ym').'.txt', $data, FILE_APPEND);
		}

		if(DEBUGING){
			global $error_messages;
			$error_messages .= "{$data}\r\n";
		}
	}

	if($isFaultError){
		ob_end_clean();
		exit("��ʱ�쳣�����Ժ����ԣ�\r\n<!-- {$errstr} -->");
	}

	if(strpos($errstr,'possibly out of free disk space')!==false){
		//���̿ռ����ˣ������Ŀ¼�µ����л���
		defined('SPACE_IS_FULL') or define('SPACE_IS_FULL',1);
	}

	return true; //Don't execute PHP internal error handler while return true
}

if( !function_exists('error_get_last') ) {
	set_error_handler(
		create_function(
			'$errno,$errstr,$errfile,$errline,$errcontext',
			'global $__error_get_last_retval__;
	        $__error_get_last_retval__ = array(
	            \'type\'        => $errno,
	            \'message\'        => $errstr,
	            \'file\'        => $errfile,
	            \'line\'        => $errline
	        );
	        return false;'
		)
	);
	function error_get_last() {
		global $__error_get_last_retval__;
		if( !isset($__error_get_last_retval__) ) {
			return null;
		}
		return $__error_get_last_retval__;
	}
}

/**
 * ��������ַ���ݿ���ṹ AUTOINCREMENT NOT NULL UNIQUE
 */
function install_database($db){
	$sql = <<<END
		CREATE TABLE "urls" (
			"id" INTEGER PRIMARY KEY,
			"url" TEXT NOT NULL UNIQUE,
			"addtime" INTEGER NOT NULL DEFAULT 0,
			"clickcount" INTEGER NOT NULL DEFAULT 0,
			"clicktime" INTEGER NOT NULL DEFAULT 0
		);
END;
	$db->query($sql);
}

/**
 * ��ʾ��Ϣ
 * @param string $category
 * @param mixed $message
 */
function show_report($category, $message=null) {
	header('Content-Type: text/html; charset='.APP_CHARSET);
	$data = array(
		'category' => $category,
		'message' => $message,
	);
	include APPDIR.'/include/message.inc.php';
	exit;
}

/**
 * ��ʾ�򵥵Ĵ�����Ϣ�����������ҳ�Ͳ�����κ��������ݣ�����ǿ��ҳ���������ڿ��ҳ
 * @param int $responseCode
 * @param mixed $message
 */
function show_error($responseCode, $message=null) {
	global $config, $isframe;
	$header = null;
	switch($responseCode){
	    case 400:
	        $header = '400 Bad Request';
	        break;
		case 403:
			$header = '403 Forbidden';
			break;
		case 404:
			$header = '404 Not Found';
			break;
		case 500:
			$header = '500 Server Error';
			break;
		case 501:
			$header = '501 Not implemented';
			break;
		case 504:
			$header = '504 Gateway Timeout';
			break;
		default:
			throw new Exception('$responseCode error!');
	}
	if($header){
		header('HTTP/1.1 '.$header);
	}

	if($message===null){
		$message = $header;
	}

	if($message){
		$accept = isset($_SERVER['HTTP_ACCEPT']) ? $_SERVER['HTTP_ACCEPT'] : 'text/html';
		$isajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH']=='XMLHttpRequest';
		if(!$isajax && substr($accept,0,5)=='text/html'){
			if(empty($_GET[$config['ctype_var_name']])){
				echo $message;
			}elseif($_GET[$config['ctype_var_name']]=='frame'){
				//�ж������iframe���������ڵ�iframe
				echo '<script type="text/javascript">if(top.document!=document){var s=parent.document.getElementsByTagName("iframe");for(var k in s)try{if(s[k].contentWindow==window){s[k].style.display="none"; break;}}catch(e){}}</script>';
			}
		}elseif(strpos($accept,'javascript') || strpos($accept,'css')){
			echo "/* {$message} */";
		}elseif(strpos($accept,'xml')){
			echo "<error>{$message}</error>";
		}
	}

	exit;
}

/**
 * ���ռ�֧�����
 * @return mixed ����ɹ�����true�����򷵻ش�����Ϣ����
 */
function check_requirement()
{
	$errors = array();

	$http = Http::create();
	if($http===false){
		$errors[] = '��������ֹ��pfsockopen��fsockopen������Ҳ��֧�� curl ģ�飬Ҳû����allow_url_fopen���ã��޷�ʹ�ñ�����';
	}else{
		unset($http);
	}

	if(!function_exists('unpack')){
		$errors[] = "��������֧�ֻ������ unpack �������޷�ʹ�ñ�����";
	}

	if(!extension_loaded('pcre')){
		$errors[] = "��������֧�� pcre ģ�飬�޷�ʹ�ñ�����";
	}

	if(!is_dir(TEMPDIR)) {
		mkdir(TEMPDIR,0644,true) or $errors[] = '�޷����� temp Ŀ¼�������Ŀ¼��д��Ȩ��';
	}
	if(!is_dir(DATADIR)) {
		mkdir(DATADIR,0644,true) or $errors[] = '�޷����� data Ŀ¼�������Ŀ¼��д��Ȩ��';
	}
	$testdb = DATADIR.'/~guestbook.db';
	$db = new Db('sqlite', $testdb);
	if($db->error()){
		$errors['db'] = '��������֧�� SQLite ���ݿ⣬�޷�ʹ�ö���ַ���ܺ����Ա�����';
	}else{
		$db->disconnect();
		unset($db);
	}
	@unlink($testdb);

	return empty($errors) ? true : $errors;
}

/**
 * ����ײ�������(����js������ʽ���������Ա���ÿ��ҳ�涼���Ӵ���)
 */
function show_navigation_js(){
	global $currentUrl, $address, $bottom_navigation, $config;

	if(!$bottom_navigation['enable']) {
		header('HTTP/1.1 200 OK');
		header('Content-Type: application/javascript; charset='.APP_CHARSET);
		header('Cache-Control: public, max-age=86400');
		header('Expires: '.gmtDate("+1 day"));
		exit;
	}

	//�ӻ������ȡ��������ÿ�ո��£��������ñ仯����£�
	$video_data_file = DATADIR.'/video.dat';
	$faq_data_file = DATADIR.'/faq.dat';
	$templateFile = isset($config['plugin']) && file_exists(APPDIR."/plugin/{$config['plugin']}_navigation.htm") ?
	    (APPDIR."/plugin/{$config['plugin']}_navigation.htm") :
	    (APPDIR.'/include/bottom_navigation.htm');
	if(Http::isMobile()){
		$templateFileM = str_replace('_navigation.htm', '_navigation_mobile.htm', $templateFile);
		if(file_exists($templateFileM)){
			$templateFile = $templateFileM;
		}
	}

	$cacheUrl = $currentUrl->home.'/btmnav/'.(Http::isMobile()?'m/':'').crc32(serialize($address+$bottom_navigation).filemtime($templateFile).filemtime($faq_data_file));
	$cache = CacheHttp::get(TEMPDIR, $cacheUrl, null, null, 3600*4);
	if($cache){
		$modified = CacheHttp::isModified($cache->headers);
		if(!$modified){
			header('HTTP/1.1 304 Not Modified');
		}else{
			header('HTTP/1.1 200 OK');
		}
		header('Content-Type: application/javascript; charset='.APP_CHARSET);
		if(isset($cache->headers['cache-control'])) header('Cache-Control: '.$cache->headers['cache-control']); else header('Cache-Control: public; max-age=86400');
		if(isset($cache->headers['last-modified'])) header('Last-Modified: '.$cache->headers['last-modified']);
		if(isset($cache->headers['expires'])) header('Expires: '.$cache->headers['expires']); else header('Expires: '.gmtDate("+1 day"));
		if(isset($cache->headers['etag'])) header('ETag: '.$cache->headers['etag']);
		if($modified){
			while(($data=$cache->read())!==false){
				echo $data;
			}
		}
		$cache->close();
		exit;
	}

	//�������뵼����ģ��
	$html = file_get_contents($templateFile);
	if(!$html) exit;
	//ת�����ֵ���Ե�ַ
	$html = preg_replace('#href=[\'"]?(\.\./)?images/#', 'href="{apppath}images/', $html);

	//׼���Ƽ�����
	if(strpos($html,'{tj}')!==false){
		$tjList = array();
		//���õ��Ƽ�
		foreach ($bottom_navigation['recommend'] as $v){
			$arr = explode('|',$v,2);
			if(count($arr)==2 && $arr[0] && $arr[1]){
				$arr[1] = $currentUrl->getFullUrl($arr[1]);
				$tjList[] = array($arr[1], $arr[0]);
			}
		}
		//�ɼ����Ƽ�
		$arr = array();
		$collectSetting = $bottom_navigation['collect'];
		if(!empty($collectSetting) && $collectSetting['url'] && ($collectUrl=Url::create($collectSetting['url'])) && $collectSetting['item_pcre']){
			$item_pcre = $collectSetting['item_pcre'];
			$http_config = $config;
			$http_config['read_cache'] = false;
			$data = Http::getHtml($collectSetting['url'], $collectSetting['useragent'], APP_CHARSET, false, $http_config);
			if($data && $collectUrl && $item_pcre && strpos($item_pcre,'(?P<link>')!==false && strpos($item_pcre,'(?P<text>')!==false){
				if($collectSetting['list_start'] || $collectSetting['list_end']){
					$data = get_between($data, $collectSetting['list_start'], $collectSetting['list_end'], false);
				}
				if($data){
					$item_pcre = '#'.str_replace('#', '\\#', $item_pcre).'#is';
					if(preg_match_all($item_pcre, $data, $matches, PREG_SET_ORDER)){
						for($i=0; $i<min(count($matches),30); $i++){
							$link = trim($matches[$i]['link']);
							$text = strtr(trim(strip_tags($matches[$i]['text'])), "", '');
							if($link && $text && !preg_match('#\s<>\'"#', $link)){
								$link = $collectUrl->getFullUrl($link,true);
								$tjList[] = array($link, $text);
							}
						}
					}
				}
			}
		}
		//�滻��ģ����
		$tj = '';
		foreach ($tjList as $v){
			$tj .= "<li>�� <a href='{$v[0]}' target='_blank'>{$v[1]}</a></li>";
		}
		$html = str_replace('{tj}', $tj, $html);
		unset($tjList);
	}

	//����
	if(strpos($html,'{link}')!==false){
		$link = '';
		foreach($address as $v){
			$arr = explode('|',$v,2);
			if(count($arr)==2 && $arr[0] && $arr[1]){
				$isDirect = $arr[1][0]=='*';
				$arr[1] = $currentUrl->getFullUrl(trim($arr[1]," \t*"));
				if($isDirect){
					$arr[1] = "{realurl}{$arr[1]}";
				}
				if(strpos($arr[1],'http://www.minghui.org')===0){
					$link = "<li><a href='{$arr[1]}' target='_blank'>{$arr[0]}</a></li>" . $link;
				}else{
					$link .= "<li><a href='{$arr[1]}' target='_blank'>{$arr[0]}</a></li>";
				}
			}
		}
		$html = str_replace('{link}', $link, $html);
	}

	//������Ƶ���ܣ���ѡ��
	if(file_exists($video_data_file)){
		if(strpos($html,'{video}')!==false){
			$link = '';
			$playlist = unserialize(@file_get_contents($video_data_file));
			if(is_array($playlist)){
			    $playlist = array_slice($playlist,0,20,true);
				foreach($playlist as $k=>$v){
					if(is_numeric($k) && is_array($v) && !empty($v['show'])){
						$playurl = "{apppath}video/play/{$k}.html";
						$link .= "<li><a href='{$playurl}' target='_blank'>{$v['title']}</a></li>";
					}
				}
			}
			$html = str_replace('{video}', $link, $html);
		}
	}else{
		$html = preg_replace('#/\*video_start\*/.*?/\*video_end\*/#is', '', $html);
	}

	//�����ʴ�����Թ��ܣ���ѡ��
	$have_faq = strpos($html,'{faq}')!==false && file_exists($faq_data_file);
	$have_guestbook = file_exists(APPDIR.'/guestbook.php');
	if(!$have_guestbook && !$have_faq){
		$html = preg_replace('#/\*faq_guestbook_start\*/.*?/\*faq_guestbook_end\*/#is', '', $html);
	}if(!$have_guestbook){
		$html = preg_replace('#/\*guestbook_start\*/.*?/\*guestbook_end\*/#is', '', $html);
	}

	if($have_faq){
		$faq = '';
		$list = unserialize(@file_get_contents($faq_data_file));
		if(is_array($list)){
		    $list = array_slice($list,0,20,true);
			foreach($list as $k=>$v){
				if(is_numeric($k)){
					$faq .= "<li><a href='{apppath}faq.php?id={$k}' target='_blank' title='{$v['title']}' target='_blank'>".mb_substr($v['title'],0,28,APP_CHARSET)."</a></li>";
				}
			}
		}
		$html = str_replace('{faq}', $faq, $html);
	}else{
		$html = preg_replace('#/\*faq_start\*/.*?/\*faq_end\*/#is', '', $html);
	}

	//�滻cookie��
	$html = str_replace('{cookie_bottom_navigation}', $config['cookie_bottom_navigation'], $html);

	//���ܲ��滻����
	$urlCoding = new UrlCoding($currentUrl);
	$urlCoding->ignoreWhiteDomains = true;
	$urlCoding->isHomepage = true;
	$tempHtmlCoding = new HtmlCoding($currentUrl, $currentUrl, $urlCoding);
	$html = $tempHtmlCoding->proxifyHtml($html);
	$html = $tempHtmlCoding->replaceVar($html);

	//ʹ���Զ���ĺ�����Ҫ��ʾ�������M���ټӹ�
	if(function_exists('my_show_navigation_js')){
		$html = my_show_navigation_js($html);
	}

	//ѹ������
	$html = preg_replace(
		array('#[\r\n][ \t]*/\*.+?\*/[ \t]*[\r\n]#', '#[\r\n][ \t]*//.*?[\r\n]#', '#[ \t]{2,}#', '#[\r\n]+\s*#'),
		array("\n", "\n", ' ', "\n"),
		$html);

	//���ܴ���
	if(isset($config['only_encodehz']) && $config['only_encodehz']=='*'){
	    $html = $tempHtmlCoding->encodeHanzi($html, APP_CHARSET);
	    $html = str_replace(array("\r","\n","'"), array('\r','\n',"\\'"), $html);
	    $html = "document.write('$html');";
	}else{
	    if(APP_CHARSET!='UTF-8') $html = mb_convert_encoding($html, 'UTF-8', APP_CHARSET);
    	$key = substr(str_shuffle('!@#=:;,'),0,1);
    	$html = strtr(str_replace('.','%2e',rawurlencode($html)),'%',$key);
    	$html = 'var s="'.$html.'"; var s=s.replace(/'.$key.'/g,"%"); document.write(decodeURIComponent(s));';
	}

	//д�뻺��
	$headers=array(
		'cache-control' => 'public, max-age=86400',
		'last-modified' => gmtDate(TIME),
		'expires' => gmtDate("+1 day"),
		'etag' => CacheHttp::makeEtag($bottom_navigation),
	);
	$cache = CacheHttp::create(TEMPDIR, $cacheUrl, $headers, null, 3600*24);
	if($cache){
		$cache->write($html);
		$cache->finish();
		$cache->close();
	}
	//���
	header('Content-Type: text/javascript; charset='.APP_CHARSET);
	header('Cache-Control: '.$headers['cache-control']);
	header('Last-Modified: '.$headers['last-modified']);
	header('Expires: '.$headers['expires']);
	header('ETag: '.$headers['etag']);
	echo $html;
}

/**
 * �жϱ����ǲ���utf-8
 */
function is_utf8($str) {
	static $charsetLoaded=false;
	if(!$charsetLoaded){
		require_once(APPDIR.'/include/charset.inc.php');
		$charsetLoaded=true;
	}
	return Charset::isUtf8($str);
}

/**
 * ����ת��
 */
function my_mb_convert_encoding($str, $to_encoding, $from_encoding) {
    static $charset=null;
    if($charset===null){
        require_once(APPDIR.'/include/charset.inc.php');
        $charset=new Charset();
    }
    return $charset->convert($str, $to_encoding, $from_encoding);
}
if(!function_exists('mb_convert_encoding')){
	function mb_convert_encoding($str, $to_encoding, $from_encoding) {
		return my_mb_convert_encoding($str, $to_encoding, $from_encoding);
	}
}

/**
 * ��ʾ ad.inc.php �����õĹ�棨ֻ��ʾָ����С�Ĺ�棬������ʾ��ǰ�����Ĺ�棩
 * @param int $width
 * @param int $height
 * @param UrlCoding $urlCoding url�������
 * @param string $css ������css��ʽ
 * @return string javascript��ʽ�Ĺ��html����
 */
function get_ad_code($width, $height, $urlCoding=null, $css=null, $adlist=null){
	static $_adlist=false;
	static $cachedUrlCoding=null;
	static $adkeys=null;

	if($adlist===null){
		if($_adlist===false) {
			$_adlist = @include(APPDIR.'/ad.inc.php');
			//���������鵥��ʹ�ã�Ӧ��ȡ�����е�ע��
			//if($ad===false) $ad = @include(APPDIR.'/ad.inc.php');
		}
		$adlist = $_adlist;
	}
	if(!is_array($adlist) || empty($adlist)) return '';

	if($urlCoding){
		$cachedUrlCoding = $urlCoding;
	}else{
		$urlCoding = $cachedUrlCoding;
	}
	if($urlCoding){
		$currentUrl = $urlCoding->currentUrl;
		$remoteUrl = $urlCoding->remoteUrl;
	}else{
		$currentUrl = Url::getCurrentUrl();
		$remoteUrl = $currentUrl;
		$urlCoding = new UrlCoding($currentUrl, $remoteUrl);
	}

	if($adkeys===null){
		$adkeys = array(
				Url::getRootDomain($currentUrl->host),
		);
		if($currentUrl != $remoteUrl){
			$adkeys[] = $remoteUrl->home.$remoteUrl->script;
			$adkeys[] = $remoteUrl->host;
			if(($root_domain=Url::getRootDomain($remoteUrl->host)) && $root_domain!=$remoteUrl->host){
				$adkeys[] = $root_domain;
			}
		}
		$adkeys[] = '';
	}

	$ret = null;
	$ratio = round($height / $width, 1);
	foreach($adkeys as $k){
		$prefix = $k ? ($k.'_') : '';
		$key1 = "{$prefix}{$width}_{$height}";
		$key2 = "{$prefix}1:{$ratio}";
		if(isset($adlist[$key1]) && !empty($adlist[$key1])){
			$ret = $adlist[$key1];
			break;
		}elseif(isset($adlist[$key2]) && !empty($adlist[$key2])){
			$ret = $adlist[$key2];
			break;
		}
	}

	if($ret){
		if(is_array($ret) && !empty($ret) && is_numeric($rand = array_rand($ret,1))){
			//�����ǹ�����飬ȡ�����Ԫ��
			$ret = $ret[$rand];
		}

		if(isset($ret['url']) && !empty($ret['url'])){
			$url = str_replace('{apppath}', $currentUrl->home.'/', $ret['url']);
			$url = $currentUrl->getFullUrl($url);
			$url = $urlCoding->encodeUrl($url);
		}else{
			$url = '';
		}

		if(is_string($ret)){
			//����HTML�����루���ֵ���ַ�����ܣ�
		}else{
			$containerCss = isset($ret['css']) ? $ret['css'] : null;
			if(isset($ret['image']) && !empty($ret['image'])){
				//ͼƬ��棨��ַ�Զ����ܣ�
				$image = is_array($ret['image']) ? $ret['image'][array_rand($ret['image'],1)] : $ret['image'];
				$image = str_replace('{apppath}', $currentUrl->home.'/', $image);
				$image = $currentUrl->getFullUrl($image, true, '/images/ad/');
				$imageHtml = "<img src=\"{$image}\" width=\"{$width}\" height=\"{$height}\" border=\"0\" />";
				if($url){
					$ret = "<a href=\"{$url}\" target=\"_blank\">{$imageHtml}</a>";
				}else{
					$ret = $imageHtml;
				}
			}elseif(isset($ret['text']) && !empty($ret['text'])){
				//���ֹ�棨��ַ�Զ����ܣ�
				$text = is_array($ret['text']) ? $ret['text'][array_rand($ret['text'],1)] : $ret['text'];
				if($url){
					$ret = "<a href=\"{$url}\" target=\"_blank\">{$text}</a>";
				}else{
					$ret = $ret['text'];
				}
			}elseif(isset($ret['flash']) && !empty($ret['flash'])){
				//flash��棨��������ַ�������Ҫ��ַ������д��swf��ߣ�
				$flash = is_array($ret['flash']) ? $ret['flash'][array_rand($ret['flash'],1)] : $ret['flash'];
				$flash = str_replace('{apppath}', $currentUrl->home.'/', $flash);
				$flash = $currentUrl->getFullUrl($flash, true, '/images/ad/');
				$ret = <<<EOF
<object type="application/x-shockwave-flash" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="{$width}" height="{$height}">
  <param name="movie" value="{$flash}" />
  <param name="quality" value="high" />
  <param name="wmode" value="opaque" />
  <!--[if !IE]>-->
  <object type="application/x-shockwave-flash" data="{$flash}" width="{$width}" height="{$height}">
    <!--<![endif]-->
    <param name="quality" value="high" />
    <param name="wmode" value="opaque" />
    <div>
      <h4>��ҳ���ϵ�������Ҫ���°汾�� Adobe Flash Player��</h4>
      <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="��ȡ Adobe Flash Player" /></a></p>
    </div>
    <!--[if !IE]>-->
  </object>
  <!--<![endif]-->
</object>
EOF;
			}elseif(isset($ret['html']) && !empty($ret['html'])){
				//�Ѿ���ϺõĹ����루���ֵ���ַ�����ܣ�
				$ret = is_array($ret['html']) ? $ret['html'][array_rand($ret['html'],1)] : $ret['html'];
			}elseif(is_array($ret)){
				$ret = '';
			}

			if($ret && $containerCss){
				$ret = "<div style=\"{$containerCss}\">{$ret}</div>";
			}
		}

		if($css){
			//ʹ����ʽ����
			return "<div style=\"{$css}\">{$ret}</div>";
		}else{
			return $ret;
		}
	}else{
		//û�з��ϵĹ��
		return '';
	}
}

/*
 * ����url�жϻ����ѡ�url��������ֻ����һ����ѯ�������ܶ��ļ�Ϊ�˰汾���Ƶ�Ŀ�ز�����һ��������������չ����$resource_file_exts�б��
* @param string $url Ҫ�����url
* @param string &$cacheSalt
* @param string &$ext
* @return bool �������Դ�ļ��ͷ���true�����򷵻�false
*/
// function getResourceCacheOptions($url, &$cacheSalt, &$ext){
// 	global $config, $image_file_exts, $download_file_exts, $media_file_exts, $currentUrl;
// 	$resource_file_exts = $image_file_exts . $download_file_exts . $media_file_exts;
// 	$cacheSalt=$ext = null;
// 	if(preg_match('#^[^\?&]+?(\.\w{2,4})(\?[^=&]+=?[^=&]*)?$#S', $url, $match)){
// 		$ext=strtolower($match[1]);
// 		if(strpos($resource_file_exts," {$ext} ")!==false){
// 			$cacheSalt=strpos(' .js .css .xml '," {$ext} ")!==false ? $config['cache_salt_for_supported'] : null;
// 			return true;
// 		}
// 	}
// 	return false;
// }

/**
 * ����url����ctype�ж��Ƿ��������Ƶ��Ƶ��ý���ļ�
 * @param string $url
 * @param string $ctype
 * @param string &$ext ������ȡ������չ��
 * @return bool
 */
// function isMediaFile($url, $ctype, &$ext){
// 	global $media_file_exts;
// 	$ext=fileext($url);
// 	return ($ctype && strpos(' embed param '," {$ctype} ")!==false) || ($ext && strpos($media_file_exts," {$ext} ")!==false);
// }

/**
 * ��youtube����ҳ����ȡ������Ƶ�ĵ�ַ
 */
function getYoutubeVideoUrl($videoId, $html=null, $debug=false){
	if(!$videoId){
		return null;
	}

	$ret = CacheFile::get("youtube:{$videoId}", 60);
	if($ret && !$debug){
		return $ret;
	}

	if(!$html){
		global $config;
		$url = "https://www.youtube.com/watch?v={$videoId}";
		$http_config = $config;
		$http_config['connect_timeout']=10;
		$http_config['read_timeout']=30;
		$http_config['read_cache'] = false;
		$_SERVER['HTTP_ACCEPT_LANGUAGE'] = 'zh-CN,zh;q=0.8';
		for($i=1; $i<=2; $i++){
		  $html = Http::getHtml($url, 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)', null, false, $http_config);
		  if($html) break;
		}
		if(!$html) return null;
	}

	if (preg_match('#url_encoded_fmt_stream_map["\']:\s*["\']([^"\'\s]*)#', $html, $url_encoded_fmt_stream_map)) {
		$fmt_maps = explode(',', $url_encoded_fmt_stream_map[1]);
		$fmt_maps = array_reverse($fmt_maps);

        $urls = array();
        $videoType = null;
		foreach ($fmt_maps as $fmt_map) {
		    if(preg_match('#[^\w]video(%2F|/)(x-flv|mp4)[^\w]#i', $fmt_map, $match)){
		        $videoType = $match[2];
		    }else{
		        continue;
		    }
		    if(isset($urls[$videoType])) continue;

			$fmt_map = '\\u0026'.$fmt_map.'\\u0026';
			preg_match('/url=([^\\\\]*)/', $fmt_map, $yt_url);
			$url = urldecode($yt_url[1]);
			if (!$url) continue;

			if(preg_match('/\\\\u0026sig=(.+?)\\\\u0026/', $fmt_map, $yt_url)){
				$url .= "&signature={$yt_url[1]}";
			}elseif(preg_match('/\\\\u0026s=(.+?)\\\\u0026/', $fmt_map, $yt_url)){
			    include_once(APPDIR.'/include/youtube.inc.php');
				$url .= "&signature=".getYoutubeSignature($html, $yt_url[1], $debug);
			}
			$urls[$videoType] = $url;
			if($videoType=='mp4') break;
		}

		if(!empty($urls)){
    		$url = isset($urls['mp4']) ? $urls['mp4'] : $urls['x-flv'];
    		CacheFile::set("youtube:{$videoId}", $url);
		}else{
		    $url = '/blank/cannot_found_video';
		    CacheFile::set("youtube:{$videoId}", $url);
		}
		return $url;

	}elseif(stripos($html, 'this video is private')!==false){
		$url = '/blank/this_video_is_private';
		CacheFile::set("youtube:{$videoId}", $url);
		return $url;
	}

	return null;
}

/**
 * ��youtube����ҳ����ȡ�����б�����
 */
function getYoutubePlaylist($listid, $path){
	global $config;

	if(!$listid){
		return null;
	}

	$ret = CacheFile::get("youtube_list:{$listid}", 600);
	if($ret){
		return str_replace('{{pre}}', "{$path}{$config['built_in_name']}", $ret);
	}

	$code = '';
	global $config;
	$url = "https://www.youtube.com/list_ajax?style=json&action_get_list=1&list={$listid}";
	$http_config = $config;
	$http_config['read_cache'] = false;
	for($i=1; $i<=2; $i++){
        $http = Http::create($http_config);
        if($http===false) return false;
        $http->setRequestHeader('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)');
        $code = $http->get($url);
        if($http->lastError==400) break;
        if($code){
            $code = $http->responseBody;
            break;
        }
        $http->close();
	}

	if($code){
	    $json = json_decode($code);
	    $code = '<rss version="2.0" xmlns:jwplayer="http://rss.jwpcdn.com/"><channel>';
	    foreach ($json->video as $v){
	        $vid = $v->encrypted_id;
	        $title = $v->title;
	        if($_SERVER["REQUEST_SCHEME"]=='http'){
		        $title = str_rot13(urlencode($title));
		        if($title) $title='%r%'.$title;
	        }
	        $code .= "<item><title><![CDATA[{$title}]]></title><guid>{$vid}</guid><jwplayer:image>{{pre}}_ytbimg_{$vid}</jwplayer:image><jwplayer:source file=\"{{pre}}_ytb_{$vid}\" /></item>";
	    }
	    $code .= '</channel></rss>';
	    CacheFile::set("youtube_list:{$listid}", $code);
		return str_replace('{{pre}}', "{$path}{$config['built_in_name']}", $code);
	}

	return null;
}

//�����û�ip��ȡ�û����ڹ���
function get_user_country(){
    static $country = null;
    if(!is_null($country)){
        return $country;
    }
    $geoipFile = APPDIR.'/data/geoip.dat';
    $geoipFileTemp = APPDIR.'/data/geoip_temp.dat';
    $ip = get_ip();
    if($ip=='127.0.0.1' || substr($ip,0,8)=='192.168.'){
        return 'LOCAL';
    }

    require_once(APPDIR.'/include/geoip.inc.php');

    //��ÿ��11�յ�0-8�����geoip���ݣ���Ϊ��������ÿ�µ�һ���ܶ�����
    $x = date('jH');
    if(($x>1101 && $x<1108) || !file_exists($geoipFile)){
        $lock = new FileLock('geoip');
        if($lock->lock(600,0)){
            //����
            global $config;
            set_time_limit(600);
            $content = http_get('http://geolite.maxmind.com/download/geoip/database/GeoLiteCountry/GeoIP.dat.gz', array('timeout'=>600, 'proxy'=>$config['proxy']));
            if($content){
                //��ѹ
                $s = my_gzdecode($content);
                $content = $s===false ? $content : $s;
                if(file_put_contents($geoipFileTemp, $content)){
                    //����
                    $country = false;
                    $gi = geoip_open($geoipFileTemp, GEOIP_STANDARD);
                    if($gi->shmid || $gi->filehandle){
                        $country = geoip_country_code_by_addr($gi, '8.8.8.8');
                    }
                    geoip_close($gi);
                    if($country=='US'){
                        if(file_exists($geoipFile)) unlink($geoipFile);
                        rename($geoipFileTemp, $geoipFile);
                    }
                }
            }
            $lock->unlock();
        }
        $lock = null;
    }

    //��ȡ����
    $country = false;
    if(file_exists($geoipFile)){
        $gi = geoip_open($geoipFile, GEOIP_STANDARD);
        if($gi->shmid || $gi->filehandle){
            $country = geoip_country_code_by_addr($gi, $ip);
        }
        geoip_close($gi);
    }
    return $country;
}

/**
 * ��ȡ�������й�Ƶ�������б�
 */
function get_ntdtv_ch1china(){
    //ÿСʱ����һ��
    $date = date('YmdH');
    $scheduleFile = APPDIR.'/data/ntdtv_ch1china.dat';
    if(file_exists($scheduleFile)){
        $content = file_get_contents($scheduleFile);
        if(substr($content,0,10)==$date){
            return unserialize(substr($content,10));
        }
    }

    //���ؽ�Ŀ��
    $arr = array();
    $lock = new FileLock('ntdtv_ch1china');
    if($lock->lock(600,0)){
        global $config;
        set_time_limit(600);
        $content = http_get('http://www.ntdtv.com/xtr/gb/tv_ch1china.html', array('timeout'=>600, 'proxy'=>$config['proxy']));
        if($content){
            $s = my_gzdecode($content);
            $content = $s===false ? $content : $s;
            //$content = mb_convert_encoding($content, 'GBK', 'utf-8');
            if(preg_match('#<div class="content curr">\s*<div class="section">(.+?)<div class="content">#sS', $content, $match)){
                if(preg_match_all('#<li .*?>\s*<span class="time">([\d:]+)</span>\s*<span class="name">(.+?)</span>\s*</li>#sS', $match[1], $submatches, PREG_SET_ORDER)){
                    foreach($submatches as $m){
                        $arr[] = array($m[1], $m[2]);
                    }
                }
            }
        }
        $lock->unlock();
    }
    $lock = null;

    if(!empty($arr)){
        $content = $date . serialize($arr);
        file_put_contents($scheduleFile, $content);
    }
    return json_encode($arr);
}

