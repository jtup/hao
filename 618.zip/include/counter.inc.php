<?php
define('STATS_COLUMN_WIDTH', 10);
define('STATS_COLUMN_MARGIN', 10);
define('STATS_LABEL_HEIGHT', 16);
define('STATS_HEIGHT', 150);
define('STATS_WIDTH', (STATS_COLUMN_WIDTH+STATS_COLUMN_MARGIN)*32);
header('Content-Type: text/html; charset=GBK');

if(APP_CHARSET!='GBK'){
	foreach($option as $k=>$v){
		$option[$k] = mb_convert_encoding($v, 'GBK', APP_CHARSET);
	}
}

//��ʾͳ��ͼ��
function showStats($arr, $title){
	if(empty($arr)){
		$max_k=0;
		$max_v=0;
	}else{
		$max_k=max(array_keys($arr));
		$max_v=max(array_values($arr));
	}
	echo '<div class="statsContainer"><div class="title">'.$title.'</div><div class="stats">';
	$index = 0;
	for($k=1; $k<=$max_k; $k++) {
		$v = isset($arr[$k])?$arr[$k]:0;
		$height = $max_v ? intval((STATS_HEIGHT-STATS_LABEL_HEIGHT)*$v/$max_v) : 0;
		$top = (STATS_HEIGHT-$height-1);
		$left = $index++ * (STATS_COLUMN_WIDTH+STATS_COLUMN_MARGIN) + STATS_COLUMN_MARGIN/2;
		echo '<div class="xvalue" style="left:'.$left.'px; top:'.($top-STATS_LABEL_HEIGHT).'px;">'.($v>0?$v:'').'</div>';
		if($v>0) echo '<div class="column" style="height:'.$height.'px; left:'.$left.'px; top:'.$top.'px;"></div>';
		echo '<div class="xvalue" style="left:'.$left.'px; top:'.STATS_HEIGHT.'px;">'.$k.'</div>';
	}
	echo "</div></div>";
}

$counts=file_get_contents_safe($counter_file);
if($counts){
	$counts=unserialize($counts);
}elseif(file_exists($counter_file.'.bak')){
	$counts=unserialize(file_get_contents($counter_file.'.bak'));
}else{
	$counts=array();
}

if(isset($_GET['deldoamin'])){
	$domain=trim($_GET['deldoamin']);
	if(isset($counts['domains'],$counts['domains'][$domain])){
		unset($counts['domains'][$domain]);
		file_put_contents($counter_file, serialize($counts), LOCK_EX);
		echo '<script type="text/javascript">parent.blank(); parent.location.reload();</script>';
	}
	exit;
}else if(isset($_GET['setremark'])){
	$domain=trim($_GET['setremark']);
	$remark=mb_convert_encoding(trim($_GET['remark']), 'gbk', 'utf-8');
	if(isset($counts['domains'],$counts['domains'][$domain])){
		$counts['domains'][$domain][6]=$remark;
		file_put_contents($counter_file, serialize($counts), LOCK_EX);
		echo '<script type="text/javascript">parent.blank(); parent.location.reload();</script>';
	}
	exit;
}
?>
<!doctype html><html><head>
<meta http-equiv="content-type" content="text/html; charset=gbk">
<title><?php echo $option['title']; ?></title>
<style>
body{line-height:20px; width:790px;}
.clear{clear:both;}
.statsContainer{margin:5px; padding:5px 0 0 10px; width:<?php echo STATS_WIDTH+20;?>px; height:<?php echo STATS_HEIGHT+STATS_LABEL_HEIGHT*2+30;?>px; background-color:#FDFDFD; border:1px solid #CCC;}
.statsContainer .title{height:30px; line-height:30px; font-size:16px; font-weight:bold; text-align:center;}
.stats{position:relative; border-left:solid #333 1px; border-bottom:solid #333 1px; height:<?php echo STATS_HEIGHT; ?>px; width:<?php echo STATS_WIDTH; ?>px; margin-left:5px; }
.column{position:absolute; width:<?php echo STATS_COLUMN_WIDTH; ?>px; margin:0 <?php echo STATS_COLUMN_MARGIN/2; ?>px; border:solid 1px #CCC; border-bottom:none; background-color:#EEE;}
.xvalue{position:absolute; height:<?php echo STATS_LABEL_HEIGHT; ?>px; line-height:<?php echo STATS_LABEL_HEIGHT; ?>px; width:<?php echo STATS_COLUMN_WIDTH+STATS_COLUMN_MARGIN; ?>px; font-size:10px; text-align:center;}
#desc{background-color:#DDD; margin:5px 0; padding:10px; color:#333;}
h1{font-size:20px; height:30px; line-height:30px;}
h1 a{color:blue;}
#h1s{line-height:25px;}
#h1s h1{float:left; margin:10px 30px 10px 0px;}
table{ table-layout:fixed; empty-cells:show; border-collapse:collapse;}
th{text-align:center;}
table.t1{ border:1px solid #cad9ea;color:#666;}
table.t1 th { padding:2px 5px; border:1px solid #cad9ea; background-color:#F0F5F9;height:20px;}
table.t1 td { padding:2px; border:1px solid #cad9ea;}
table.t1 tr.a1{ background-color:#f5fafe;}
button {color:12px;padding:1px 4px;}
.caution{padding:5px; margin:10px 0; border:1px solid #CCC; background-color:#ece76b; font-size:12px; line-height:20px; color:#ff0606;}
</style>
<script type="text/javascript">
var Style=
{
    barStyle:
    {
        style1:
        {
            backgroundColor:"#ff0000"
        },
        style2:
        {
            backgroundColor:"#ffff00",
            borderStyle:"solid",
            borderWidth:"1px",
            borderColor:"#0000ff"
        }
    },

    pointStyle:
    {
        style1:
        {
            backgroundColor:"#ff0000",
            lineColor:"#ff0000"
        },
        style2:
        {
            backgroundColor:"#00ff00",
            lineColor:"#00ff00"
        }
    }
};

function Graphic(left,top)
{
    this.entity=document.createElement("div");

    this.height=200;
    this.barWidth=20;
    this.maxHeight=0;
    this.barDistance=20;
    this.topDistance=20;
    this.points=new Array();

    var This=this;
    var showPoints=new Array();
    var bars=new Array();
    var times=new Array();
    var values=new Array();
    var elements=new Array();

    function Constructor()
    {
        This.entity.style.position="absolute";
        This.entity.style.borderLeftStyle="solid";
        This.entity.style.borderLeftWidth="1px";
        This.entity.style.borderLeftColor="#000000";
        This.entity.style.borderBottomStyle="solid";
        This.entity.style.borderBottomWidth="1px";
        This.entity.style.borderBottomColor="#000000";

        This.setPosition(left,top);
        document.body.appendChild(This.entity);
    };

    this.setPosition=function(left,top)
    {
        var deltaX=left-parseInt(This.entity.style.left);
        var deltaY=top-parseInt(This.entity.style.top);
        This.entity.style.left=(isNaN(left)?"100":left)+"px";
        This.entity.style.top=(isNaN(top)?"300":top)+"px";
        for(var i=0;i<bars.length;i++)
        {
            bars[i].style.left=parseInt(bars[i].style.left)+deltaX+"px";
            bars[i].style.top=parseInt(bars[i].style.top)+deltaY+"px";

            values[i].style.left=parseInt(values[i].style.left)+deltaX+"px";
            values[i].style.top=parseInt(values[i].style.top)+deltaY+"px";

            times[i].style.left=parseInt(times[i].style.left)+deltaX+"px";
            times[i].style.top=parseInt(times[i].style.top)+deltaY+"px";
        }
    };

    this.addPoint=function(value,time)
    {
        This.points.push(
        {
            id:This.points.legnth==0?0:This.points.length-1,
            value:value,
            time:time
        });
    }

    this.showBarGraphic=function(barStyle)
    {
        for(var i=0;i<This.points.length;i++)
        {
            var bar=document.createElement("div");
            var spanValue=document.createElement("span");
            var spanTime=document.createElement("span");

            bar.value=This.points[i].value;
            bar.time=This.points[i].time;
            for(var bs in barStyle)
            {
                bar.style[bs]=barStyle[bs];
            }

            bar.style.fontSize="1px";
            bar.style.position="absolute";
            bar.style.width=This.barWidth;
            bar.style.top=parseInt(This.entity.style.top)+This.topDistance+"px";

            bar.style.left=(bars.length==0?
               parseInt(This.entity.style.left)+This.barDistance:
               parseInt(bars[bars.length-1].style.left)+parseInt(bars[bars.length-1].style.width)+This.barDistance)+"px";

            if(bar.value>This.maxHeight)
            {
                bar.style.height=This.height-This.topDistance+"px";
                This.maxHeight=bar.value;
            }

            spanValue.innerHTML=bar.value;
            spanValue.style.position="absolute";
            spanValue.style.left=bar.style.left;

            spanTime.innerHTML=bar.time;
            spanTime.style.position="absolute";
            spanTime.style.left=bar.style.left;

            bars.push(bar);
            values.push(spanValue);
            times.push(spanTime);

            document.body.appendChild(bar);
            elements.push(bar);

            document.body.appendChild(spanValue);
            elements.push(spanValue);

            document.body.appendChild(spanTime);
            elements.push(spanTime);

        }
        for(var i=0;i<bars.length;i++)
        {
            var percentage=bars[i].value/This.maxHeight;
            bars[i].style.height=(This.height-This.topDistance)*percentage+"px";
            bars[i].style.top=parseInt(This.entity.style.top)+(This.height-parseInt(bars[i].style.height))+"px";
            values[i].style.top=parseInt(bars[i].style.top)-20+"px";
            times[i].style.top=parseInt(bars[i].style.top)+parseInt(bars[i].style.height)+"px";
        }

        This.updateDisplay();
    };

    this.showPointGraphic=function(pointStyle)
    {
        for(var i=0;i<This.points.length;i++)
        {
            var showPoint=document.createElement("div");
            var spanValue=document.createElement("span");
            var spanTime=document.createElement("span");

            showPoint.value=This.points[i].value;
            showPoint.time=This.points[i].time;
            showPoint.lineColor=pointStyle.lineColor;
            for(var ps in pointStyle)
            {
                showPoint.style[ps]=pointStyle[ps];
            }

            showPoint.style.fontSize="1px";
            showPoint.style.position="absolute";
            showPoint.style.width="5px";
            showPoint.style.top=parseInt(This.entity.style.top)+This.topDistance+"px";

            showPoint.style.left=(showPoints.length==0?
                parseInt(This.entity.style.left)+This.barDistance:
                parseInt(showPoints[showPoints.length-1].style.left)+parseInt(showPoints[showPoints.length-1].style.width)+This.barDistance)+"px";

            if(showPoint.value>This.maxHeight)
            {
                This.maxHeight=showPoint.value;
            }

            spanValue.innerHTML=showPoint.value;
            spanValue.style.position="absolute";
            spanValue.style.left=showPoint.style.left;

            spanTime.innerHTML=showPoint.time;
            spanTime.style.position="absolute";
            spanTime.style.left=showPoint.style.left;

            showPoints.push(showPoint);
            values.push(spanValue);
            times.push(spanTime);

            document.body.appendChild(showPoint);
            elements.push(showPoint);

            document.body.appendChild(spanValue);
            elements.push(spanValue);

            document.body.appendChild(spanTime);
            elements.push(spanTime);

            This.updateDisplay();
            for(var j=0;j<showPoints.length;j++)
            {
                var percentage=showPoints[j].value/This.maxHeight;

                pointHeight=(This.height-This.topDistance)*percentage;
                showPoints[j].style.top=parseInt(This.entity.style.top)+(This.height-pointHeight)+"px";
                showPoints[j].style.height="15px";
                values[j].style.top=parseInt(showPoints[j].style.top)-20+"px";

                times[j].style.top=parseInt(This.entity.style.top)+parseInt(This.entity.style.height)+"px";
            }
        }
        for(var i=0;i<showPoints.length;i++)
        {
            if(i>0){
                This.drawLine(parseInt(showPoints[i-1].style.left),
                    parseInt(showPoints[i-1].style.top),
                    parseInt(showPoints[i].style.left),
                    parseInt(showPoints[i].style.top),
                    showPoints[i-1].lineColor
                );
            }
        }

    };

    this.updateDisplay=function()
    {
        This.entity.style.width=(This.barWidth+This.barDistance)*This.points.length+This.barDistance;
        This.entity.style.height=This.height;
    };

    this.drawLine=function(startX,startY,endX,endY,colorCode)
    {
        var xDirection=(endX-startX)/Math.abs(endX-startX);
        var yDirection=(endY-startY)/Math.abs(endY-startY);
        var xDistance=endX-startX;
        var yDistance=endY-startY;
        var xPercentage=1/Math.abs(endX-startX);
        var yPercentage=1/Math.abs(endY-startY);
        if(Math.abs(startX-endX)>=Math.abs(startY-endY))
        {
            for(var i=0;i<=Math.abs(xDistance);i++)
            {
                var point=document.createElement("div");
                point.style.position="absolute";
                point.style.backgroundColor=colorCode;
                point.style.fontSize="0";
                point.style.width="2px";
                point.style.height="2px";

                startX+=xDirection;
                point.style.left=startX+"px";
                startY=startY+yDistance*xPercentage;
                point.style.top=startY+"px";
                document.body.appendChild(point);
                elements.push(point);
            }
        }
        else
        {
            for(var i=0;i<=Math.abs(yDistance);i++)
            {
                var point=document.createElement("div");
                point.style.position="absolute";
                point.style.backgroundColor=colorCode;
                point.style.fontSize="0";
                point.style.width="2px";
                point.style.height="2px";

                startY+=yDirection;
                point.style.top=startY+"px";
                startX=startX+xDistance*yPercentage;
                point.style.left=startX+"px";
                document.body.appendChild(point);
                elements.push(point);
            }
        }
    };

    this.clear=function()
    {
        for(var i=0;i<elements.length;i++)
        {
            document.body.removeChild(elements[i]);
        }
        showPoints.length=0;
        bars.length=0;
        times.length=0;
        values.length=0;
        elements.length=0;
    };

    Constructor();
};

function delDomain($domain){
	if(confirm('ȷʵҪɾ���������ļ�¼��')){
		var frame=document.getElementById('_hiddenframe');
		frame.src='?<?php echo trim($_SERVER['QUERY_STRING'],'&'); ?>&deldoamin='+$domain+'&t='+(new Date).getTime();
	}
}
function blank(){
	var frame=document.getElementById('_hiddenframe');
	frame.src='about:blank';
}
function setRemark(domain, row){
	var remark = document.getElementById('remark_'+row).innerHTML;
	var frame=document.getElementById('_hiddenframe');
	var newremark = window.prompt('������ '+domain+' �ı�ע˵����', remark);
	if(newremark!=remark && typeof newremark=='string'){
		frame.src='?<?php echo trim($_SERVER['QUERY_STRING'],'&'); ?>&setremark='+domain+'&remark='+encodeURIComponent(newremark);
	}
}
</script></head>

<body>
<?php echo isset($option['header']) ? $option['header'] : "<h1>{$option['title']}</h1>"; ?>
<div style="clear:both;"></div>
<div id="desc"><?php echo $option['desc']; ?></div>

<?php
if(empty($counts)) {
	exit('��û���κ�'.$option['name'].'�ļ�¼');
}

$total_thisday = $counts['thism'][intval(substr($counts['date'],6,2))];

//����·��Ƿ�����
$recordMonth = substr($counts['date'],0,6);
if($recordMonth == date('Ym')){
	$total_lastm = intval(@$counts[date('Ym',strtotime('first day of -1 month'))]);
	$total_thism = array_sum(array_values($counts['thism']));
}else{
	$lastMonth = date('Ym',strtotime('first day of -1 month'));
	if($recordMonth==$lastMonth){
		$counts['lastm'] = $counts['thism'];
		$total_lastm = array_sum(array_values($counts['thism']));
	}else{
		$counts['lastm'] = array();
		$total_lastm = intval(@$counts[date('Ym',strtotime('first day of -1 month'))]);
	}
	$counts['thism']=array();
	$total_thism = 0;
}

echo '<br/>'.$option['name'].'������<b>'.$counts['all'].'</b>';
echo '<br/><br/>����'.$option['name'].'������<b>'.$total_lastm.'</b>';
echo '<br/><br/>����'.$option['name'].'������<b>'.$total_thism.'</b>';
echo '<br/><br/>���'.$option['name'].'���ڣ�<b>'.substr($counts['date'],0,4).'��'.substr($counts['date'],4,2).'��'.substr($counts['date'],6,2).'��</b>';
echo '<br/>����'.$option['name'].'������<b>'.$total_thisday.'</b>';

echo '<br/><br/>';
showStats($counts['thism'], '����ÿ��'.$option['name'].'��ϸ');

echo '<br/>';
showStats($counts['lastm'], '����ÿ��'.$option['name'].'��ϸ');

$hour=intval(date('Ymd').'01');
$h=intval(date('H'));
$a=array();
for($i=1;$i<=$h;$i++){
	$a[$i]=isset($counts['hour'][$hour+$i-1])?$counts['hour'][$hour+$i-1]:0;
}
echo '<br/>';
showStats($a, '���շ�ʱ��'.$option['name'].'��ϸ');

$hour=intval(date('Ymd',strtotime('-1 day')).'01');
$a=array();
for($i=1;$i<=24;$i++){
	$a[$i]=isset($counts['hour'][$hour+$i-1])?$counts['hour'][$hour+$i-1]:0;
}
echo '<br/>';
showStats($a, '���շ�ʱ��'.$option['name'].'��ϸ');


echo "<br/><h2>����������ͳ��</h2>
<table border='1' class='t1'>
<tr>
	<th nowrap='nowrap'>����</th>
	<th nowrap='nowrap'>���˴�</th>
	<th nowrap='nowrap'>����·�</th>
	<th nowrap='nowrap'>�����˴�</th>
	<th nowrap='nowrap'>�������</th>
	<th nowrap='nowrap'>�����˴�</th>
	<th nowrap='nowrap'>����������</th>
	<th nowrap='nowrap'>��ע˵��</th>
	<th nowrap='nowrap' width='100'>����</th>
</tr>";
if(is_array($counts['domains'])){
	$row=0;
	foreach($counts['domains'] as $domain=>$domainCounter){
		if(isset($domainCounter[5]) && $domainCounter[5]){
			$days = floor((time()-intval($domainCounter[5]))/86400);
		}else{
			$days = '';
		}
		echo "<tr class='a". ($row++ % 2) ."'>
		<td align='left'>{$domain}</td>
		<td align='right'>{$domainCounter[0]}</td>
		<td align='center'>{$domainCounter[1]}</td>
		<td align='right'>{$domainCounter[2]}</td>
		<td align='center'>{$domainCounter[3]}</td>
		<td align='right'>{$domainCounter[4]}</td>
		<td align='right'>{$days}</td>
		<td align='left' id='remark_{$row}'>" .(isset($domainCounter[6])?$domainCounter[6]:''). "</td>
		<td align='center' nowrap='nowrap'><button onclick=\"setRemark('{$domain}',$row);\">��ע</button> <button onclick=\"delDomain('{$domain}');\">ɾ��</button></td>
	</tr>";
	}
}
echo '</table>
<div style="color:#666; margin-top:10px;">˵��1:����������������ʾ�Ѿ�������û�б����ʹ��ˡ�</div>
<div style="color:#666; margin-top:10px;">˵��2:�������ÿ�����ָ���Ƿ���ĳ��ҳ����������ÿ͵Ķ���ظ����ֻ���¼һ�Ρ���վʹ��COOKIE��ʶ���������Ƿ����µķÿͣ�����ÿͷ��ʹ�������������COOKIE���ߴ���������������ᱻʶ��Ϊһ���·ÿͣ�����������������IP�������ᵼ�¼��������ӡ���</div>
';
?>
<br/><br/>

<iframe id='_hiddenframe' width='0' height='0' style='display:none;'></iframe>
</body>
</html>
