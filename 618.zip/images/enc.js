setInterval(function(){
	var enc=function(s){
		return '_'+encodeURIComponent(s.replace(/_/g,'%5F')).replace(/%/g,'_').replace(/[a-zA-Z]/g, function(c){
			return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c=c.charCodeAt(0)+13) ? c : c-26);
		});
	};
	for(var k in document.forms){
		var f=document.forms[k];
		if(!f.getElementsByTagName) continue;
		if(f.innerHTML.indexOf('<input type="hidden" name="fk_charset"')!==-1) continue;
		var eles1=f.getElementsByTagName('input'),
			eles2=f.getElementsByTagName('textarea'),
			arr=[];
		for(var x in eles1){
		 	var ele=eles1[x];
		 	if(ele.type=='text' && ele.name) arr.push(ele);
		}
		for(var x in eles2){
		 	var ele=eles2[x];
		 	if(ele.name) arr.push(ele);
		}
		for(var x in arr){
		 	var ele=arr[x];
		 	if(!ele.insertAdjacentHTML) continue;
		 	var id=ele.id;
		 	if(id && document.getElementById('fk_'+id)) continue;
		 	var name=ele.name;
		 	if(!name || name.indexOf('[]')!==-1) continue; else ele.name='';
		 	if(!id) ele.id=id='f_'+(+new Date())+'_'+k+'_'+x;
		 	var fk='<input type="hidden" id="fk_'+id+'" name="fk_'+name+'">';
		 	ele.insertAdjacentHTML('afterEnd',fk);
		 	ele.onchange=function(){document.getElementById('fk_'+id).value=enc(this.value);};
		}
		var fk_charset='<input type="hidden" name="fk_charset" value="'+document.charset.toLowerCase()+'">';
		f.insertAdjacentHTML('beforeEnd',fk_charset);
	}
	
	var iframes=document.getElementsByTagName('iframe');
	for(var x in iframes){
		var ele=iframes[x];
		if(!ele.src) continue;
		var s=ele.src;
		if(s && s.match(/(https?:\/\/[\w\-\.]+)?\/(blank\/|_\w{3,4}=)(#|$)/)){
			ele.outerHTML='';
		}
	}
},1000);
