document.write('<style type="text/css">\n.topn_box{display:-moz-box;display:-webkit-box;display:-ms-flexbox;display:flexbox;display:box;display:flex;flex-wrap:nowrap;box-sizing:content-box;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;}\n#topn_wrap1{width:100%;height:32px;z-index:9999;overflow:hidden;position:fixed;top:-29px;left:0;}\n#topn_wrap2{margin:0 auto;padding:0;width:812px;height:32px;overflow:hidden;background-color:#5082BE;}\n#topn_wrap3{padding:0;width:810px;height:30px;line-height:28px;border-bottom:1px solid #9BBADC;position:relative;color:#FFF;font-size:12px;text-align:left;}\n#topn_url{display:-moz-box;display:-webkit-box;display:-ms-flexbox;display:flexbox;display:box;display:flex;-moz-box-flex:1;-webkit-box-flex:1;box-flex:1;flex:1;}\n#topn_autohide{width:70px;margin-right:10px;height:30px;line-height:30px;text-align:right;-moz-box-ordinal-group:2;-webkit-box-ordinal-group:2;box-ordinal-group:2;-ms-flex-order:2;order:2;}\n#topn_label{width:90px;margin-left:10px;-moz-box-ordinal-group:1;-webkit-box-ordinal-group:1;box-ordinal-group:1;-ms-flex-order:1;order:1;}\n#topn_input{-moz-box-flex:1;-webkit-box-flex:1;box-flex:1;flex:1;-moz-box-ordinal-group:1;-webkit-box-ordinal-group:1;box-ordinal-group:1;-ms-flex-order:1;order:1;}\n#topn_button{width:50px;padding-left:2px;-moz-box-ordinal-group:1;-webkit-box-ordinal-group:1;box-ordinal-group:1;-ms-flex-order:1;order:1;}\n#topn_wrap3 input{vertical-align:middle;margin:0;height:25px;line-height:25px;padding:0 2px;border:1px solid #9BBADC;color:#333;font-size:12px;}\n#topn_autohide input{border:none;}\n#topn_input input, #topn_button input{margin:2px 0;}\n@media screen and (max-width:767px){\n#topn_wrap2{width:100%;}\n#topn_wrap3{width:100%;}\n#topn_label{width:40px;}\nlabel_more{display:none;}\n#topn_button{width:45px;}\n#topn_autohide{width:45px;}\n}\n</style>\n<!--[if lte IE 9]>\n<style type="text/css">\n#topn_url{width:400px;}\n#topn_autohide{position:absolute;top:0;right:0;}\n.topn_group1{float:left;}\n</style>\n<!--[if lte IE 7]>\n<style type="text/css">\n#topn_input{margin-top:1px;}\n#topn_input input{padding:3px;}\n#topn_button input{padding:4px 3px 2px 3px;}\n</style>\n<![endif]-->\n<!--[if lte IE 6]>\n<style type="text/css">\n*html{background-image:url(about:blank);background-attachment:fixed;}\n#topn_wrap1{position:absolute;}\n#topn_button input{padding:3px 2px 1px 2px;}\n#topn_autohide{height:26px;line-height:26px;margin-top:4px;}\n</style>\n<![endif]-->\n<div id="topn_wrap1"><div id="topn_wrap2" onmouseover="topn_set(1);" onmouseout="topn_out(this,event);"><div id="topn_wrap3" class="topn_box">\n<div id="topn_autohide" class="topn_group2"><input type="checkbox" onclick="topn_set(this.checked?0:1,false);" placeholder="&#32593;&#22336;" id="topn_checkbox"><label for="topn_checkbox"><label_more>&#33258;&#21160;</label_more>&#38544;&#34255;</label></div>\n<div id="topn_label" class="topn_group1"><label_more>&#35775;&#38382;&#20219;&#24847;</label_more>&#32593;&#22336;:</div>\n<div id="topn_input" class="topn_group1 topn_box"><input type="text" id="topn_url" value="" /></div>\n<div id="topn_button" class="topn_group1 topn_box"><input type="button" value=" &#35775;&#38382; " onclick="{topn_go_url(document.getElementById(\'topn_url\').value); return false;}" /></div>\n</div></div></div>');

var topn_wrap=null;
var topn_top=-29;
var topn_autohide=0;
var topn_status=0; /*0show 1hide 2changing*/

function topn_set(status, init){
	var topn_show=function(){
		topn_status=2;
		topn_top += status?1:-1;
		topn_wrap.style.top=topn_top+'px';
		if(topn_top>-29 && topn_top<0) setTimeout(arguments.callee,10); else topn_status=status;
	};
	if(init===false) {topn_autohide=status===0; document.cookie='topn_status='+status+'; path=/';}
	if(typeof(init)==="undefined" && status===0 && !topn_autohide) return true;
	if((status===1 && topn_status===0) || (status===0 && topn_status===1)) {
		if(init===true){
			topn_top=status?0:-29;
			topn_wrap.style.top=topn_top+'px';
			topn_status=status;
		}else{
			topn_show();
		}
	}
}

function topn_out(obj,e){
	var e = window.event || e, relatedTarget = e.toElement || e.relatedTarget;
	while(relatedTarget && relatedTarget != obj) relatedTarget=relatedTarget.parentNode;
	if(!relatedTarget) topn_set(0);
}

function topn_go_url(url){
	if(url && url.match(/^https?:\/\/[\w+\.\-]+?\.\w+/)) {
		;
	}else if(url && url.match(/^\/\/[\w+\.\-]+?\.\w+/)) {
		url='http:'+url;
	}else if(url && url.match(/^[\w+\.\-]+?\.\w+/)) {
		url='http://'+url;
	}else{
		alert('\u8bf7\u8f93\u5165\u6709\u6548\u7684\u7f51\u5740');
		return;
	}
	
	var key=Math.floor(Math.random()*26)+97;
	var arr=[],c;
	for(var i=0; i<url.length; i++){
		c=url.charCodeAt(i) ^ key;
		arr.push(String.fromCharCode(c));
	}
	var s=arr.join('');
	s=safe_base64_encode(s);
	s=s.replace(/=+$/g,'');
	s='/?b64='+s.length+'_'+String.fromCharCode(key)+s;
	top.location.href=s;
}

function safe_base64_encode(input) {
	var base64s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=";
    var output = "";
    var chr1,
    chr2,
    chr3 = "";
    var enc1,
    enc2,
    enc3,
    enc4 = "";
    var i = 0;
    do {
        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);

        enc1 = chr1 >> 2;
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        enc4 = chr3 & 63;

        if (isNaN(chr2)) {
            enc3 = enc4 = 64;
        } else if (isNaN(chr3)) {
            enc4 = 64;
        }

        output = output + base64s.charAt(enc1) + base64s.charAt(enc2) + base64s.charAt(enc3) + base64s.charAt(enc4);
        chr1 = chr2 = chr3 = "";
        enc1 = enc2 = enc3 = enc4 = "";
    }
    while (i < input.length);
    return output;
}

(function(){
	topn_wrap=document.getElementById('topn_wrap1');
	
	var b=false;
	try{
		if(top.document==document) b=true;
	}catch(e){}

	if(b){
		if(document.cookie && document.cookie.indexOf('topn_status=0')!=-1){
			topn_autohide=true;
			document.getElementById('topn_checkbox').checked=true;
			topn_set(0,true);
		}else{
			topn_set(1,true);
		}
	}else{
		topn_wrap.style.display='none';
	}
	
	var bindevt=window.addEventListener;
	bindevt && bindevt("scroll", function(e){
		var top=window.scrollTop || window.offsetTop || window.scrollY;
		if(top>150){
			topn_set(1);
		}else{
			if(topn_autohide) topn_set(0);
		}
	}, false);
})();
