<?php
require('inc.php');

check_authentication ($config_admin_password);
define('IS_ADMIN', 1);
define('IN_FRAME', 1);

if($act=='del_blocked'){
	// ======= 清空违禁记录 =======
	@unlink(DBFILE_TUI_BLOCKED);
	file_put_contents(DBFILE_TUI_LOG, date('Y-m-d h:i:s') . " 清空违禁记录 (共{$_GET['count']}条)\r\n\r\n", FILE_APPEND);
	header('Location: ?act=view_blocked');
	exit;

}elseif($act=='view_blocked'){
	// ======= 查看违禁记录 =======
	$rows = file(DBFILE_TUI_BLOCKED);
	krsort($rows);
	header('Content-Type: text/html; charset=utf-8');
	$content = implode('', $rows);
	if(!$content) $content='暂无'; else $content='<a href="?act=del_blocked&count='.count($rows).'">清空违禁记录</a><pre>'.$content.'</pre>';
	exit($content);

}elseif($act=='counter'){
	// ======= 显示访问统计 =======
	$option=array('title'=>'三退表单访问统计', 'name'=>'访问', 'file'=>DBFILE_VISIT, 'desc'=>'这里统计的是三退表单来访的独立访客数',
		'header'=>'<div id="h1s"><h1><a href="?style=">适合浏览模式</a></h1><h1><a href="?style=submit">适合提交模式</a></h1><h1>访问统计</h1><h1><a href="?act=view_blocked" target="_blank">违禁记录</a></h1><div class="clear"></div></div>');
	$counter_file = $option['file'];
	if(!include(INCLUDE_DIR.'/counter.inc.php')){
		exit('File not found: counter.inc.php');
	}
	exit;
}

if($isPost && $act=="xuhao"){
	file_put_contents_bak(DBFILE_TUI_FABIAO, $_REQUEST['xuh']);
	file_put_contents(DBFILE_TUI_LOG, date('Y-m-d h:i:s') . " 标记最后发表的声明序号为 {$_REQUEST['xuh']}\r\n\r\n", FILE_APPEND);
	isoka('保存成功！');
}

if($isPost && $act=="delete"){
	$shum=$_REQUEST['shum'];
	if($shum != 8){
		error("请先输入数字 8 ！");
	}

	$mtime = intval($_REQUEST['mtime']);
	if($mtime>0 && filemtime(DBFILE_TUI)>$mtime){
		error("数据文件在打开后又有更新了，请返回并查看后再从新清空吧 ！");
	}

	$msg="";
	$fp=fopen(DBFILE_TUI,'w');
	fputs($fp,$msg);
	fclose($fp);

	$temp="";
	$fpd=fopen(DBFILE_TUI_DONE,'w');
	fputs($fpd,$temp);
	fclose($fpd);

	$number=0;
	$fpt=fopen(DBFILE_TUI_FABIAO,'w');
	fputs($fpt,$number);
	fclose($fpt);

	unlink(DBFILE_TUI_HIDE);
	unlink(DBFILE_TUI_BLOCKED);
	file_put_contents(DBFILE_TUI_LOG, date('Y-m-d h:i:s') . " 清空一切数据\r\n\r\n", FILE_APPEND);

	isoka("所有数据已经清空！");
}

//屏蔽与恢复
$list_hide = file_exists(DBFILE_TUI_HIDE) ? file_get_contents(DBFILE_TUI_HIDE) : '';
$list_hide = strlen($list_hide)>0 ? explode(',',$list_hide) : array();
if($act=="v"){
	$hide = intval($_GET['hide']);
	$id = intval($_GET['id']);
	if($id>0){
		$key = array_search($id, $list_hide);
		if($key!==false && $hide===0){
			//恢复
			unset($list_hide[$key]);
			file_put_contents(DBFILE_TUI_HIDE, implode(',', $list_hide));
		}elseif($key===false && $hide===1){
			//屏蔽
			$list_hide[] = $id;
			file_put_contents(DBFILE_TUI_HIDE, implode(',', $list_hide));
		}
	}
	exit;
}

$blocked = array();
if(!file_exists(DBFILE_TUI_BLOCKED) || filesize(DBFILE_TUI_BLOCKED)==0){
	$blocked_count = 0;
}else{
	$rows = file(DBFILE_TUI_BLOCKED);
	$blocked_count = count($rows);
	foreach($rows as $row){
		$arr = explode(' ',strtr($row, "\t"," "));
		if(count($arr)>=7) $blocked["{$arr[1]}{$arr[4]}"]=1;
	}
}

$rows = file_exists(DBFILE_TUI) ? file(DBFILE_TUI) : array();
$recordCount = $rows?count($rows):0;
$number = file_exists(DBFILE_TUI_FABIAO) ? intval(file_get_contents(DBFILE_TUI_FABIAO)) : 0;

$option = empty($_COOKIE['options']) ? null : unserialize(urlsafe_base64_decode($_COOKIE['options']));
if(!is_array($option)) $option=array('style'=>null, 'referer'=>1, 'agent'=>0);
if(isset($_GET['style']) || isset($_GET['referer']) || isset($_GET['agent'])){
	if(isset($_GET['style'])) $option['style'] = in_array($_GET['style'],array('submit','blocked'))?$_GET['style']:null;
	if(isset($_GET['referer'])) $option['referer'] = intval($_GET['referer']);
	if(isset($_GET['agent'])) $option['agent'] = intval($_GET['agent']);
	setcookie('options', urlsafe_base64_encode(serialize($option)));
}

$content_names = array(
	'1' => array('共产党', '退党'),
	'2' => array('共青团', '退团'),
	'3' => array('少先队', '退队'),
	'12' => array('共产党和共青团', '退党团'),
	'23' => array('共青团和少先队 ', '退团队'),
	'13' => array('共产党和少先队', '退党队'),
	'123' => array('共产党、共青团和少先队', '退党团队'),
);

head('三退管理');

if($option['style']=='submit'){
	echo '<div id="h1s"><h1><a href="?style=">适合浏览模式</a></h1><h1>适合提交模式</h1><h1><a href="?act=counter">访问统计</a></h1><h1><a href="?act=view_blocked" target="_blank">违禁记录('.$blocked_count.')</a></h1><div class="clear"></div></div>';
}else{
	echo '<div id="h1s"><h1>适合浏览模式</h1><h1><a href="?style=submit">适合提交模式</a></h1><h1><a href="?act=counter">访问统计</a></h1><h1><a href="?act=view_blocked" target="_blank">违禁记录('.$blocked_count.')</a></h1><div class="clear"></div></div>';
}

echo <<<EOF
<style type="text/css">
body{color:#333;}
#list{line-height:1.5;color:#333;}
#tbl_tui tr.blocked{color:red; background-color:yellow;}
#tbl_tui tr.hide{color:#666; background-color:#666; line-height:10px;}
#tbl_tui tr.hide td{height:10px; line-height:10px; font-size:6px; overflow:hidden;}
#tbl_tui .btn_v{color:#999;}
#tbl_tui tr.hide .btn_h{color:#999;}
#tbl_tui tr.hide .btn_v{color:#333;}
#splitday, #subtotals{width:18px; height:18px;}
</style>
<script type="text/javascript">
function $(id){return document.getElementById(id);}
</script>
EOF;

// ======= 普通浏览模式 =======

if(!$option['style']){
	$page=isset($_GET['page'])?intval($_GET['page']):1;
	if($page<1){$page=1;}
	$pageCount=ceil($recordCount/$config_pagesize);
	$offset=($page-1)*$config_pagesize; //计算开始条数
?>
<script type="text/javascript">
function v(id,hide){
	var frame=$('_hiddenframe');
	var tr = $("row_"+id);
	if(hide) tr.className+=' hide'; else tr.className=tr.className.replace(' hide','');
	frame.src='?act=v&hide='+hide+'&id='+id;
}
</script>

<div class="infos">
	<form action="?" name="xuhao" method="post">
	最后发表声明的序号：
	<input name="xuh" type="text" size="5" maxlength="5" >
	<input type="submit" value="提交">
	<input type="hidden" name="act" value="xuhao">
	<span>&nbsp;&nbsp;&nbsp;已经发表到第 <b class="red"><?php echo "$number" ?></b> 个 </span>

	&nbsp;

	<?php if($option['referer']){ ?>
	<input type="reset" onclick="location.href='?referer=0'; return false;" value="  隐藏来源  "/>
	<?php }else{ ?>
	<input type="reset" onclick="location.href='?referer=1'; return false;" value="  显示来源  "/>
	<?php } ?>

	<?php if($option['agent']){ ?>
	<input type="reset" onclick="location.href='?agent=0'; return false;" value="  隐藏UserAgent  "/>
	<?php }else{ ?>
	<input type="reset" onclick="location.href='?agent=1'; return false;" value="  显示UserAgent  "/>
	<?php } ?>

  </form>
</div>

<table border="1" id="tbl_tui" class="t1">
  <thead>
  	<th nowrap="nowrap">序号</th>
  	<th nowrap="nowrap">姓名</th>
  	<th nowrap="nowrap">Email</th>
  	<th nowrap="nowrap">内容</th>
  	<th nowrap="nowrap">IP</th>
  	<th nowrap="nowrap">提交时间</th>
  	<?php if($option['referer']){ ?><th nowrap="nowrap">来源页面</th><?php } ?>
  	<?php if($option['agent']){ ?><th nowrap="nowrap">User-Agent</th><?php } ?>
  	<th nowrap="nowrap">屏蔽</th>
  </thead>
<?php
for($last=$recordCount-$page*$config_pagesize-1, $i=$recordCount-($page-1)*$config_pagesize-1; $i>=0 && $i>$last; $i--){
	$row=explode(COLUMN_DELIMITER, trim($rows[$i]));
	foreach($tui_fields as $k=>$v){
		$row[$k] = isset($row[$v])?$row[$v]:'';
	}

	$content = $row['content'] ? ($content_names[trim($row['content'])][0] . ($row['special'] ? " & {$row['special']}" : '')) : $row['special'];
	$className = 'a'.$i%2;
	$arr = explode(' ', $row['addtime']);
	if(isset($blocked["{$arr[0]}{$row['ip']}"])) $className.=' blocked';
	if(in_array($row['id'],$list_hide)) $className.=' hide';

?>
  <tr class="<?php echo $className; ?>" id="row_<?php echo $row['id']; ?>" onmousemove="this.style.backgroundColor='#FCDFE1'" onmouseout="this.style.backgroundColor=''">
  	<td nowrap="nowrap" align="center" <?php if($row['id']>$number) echo 'class="red"'?>><?php echo $row['id']; ?></td>
  	<td nowrap="nowrap"><?php echo $row['name']; ?></td>
  	<td nowrap="nowrap"><?php echo $row['email']; ?></td>
  	<td nowrap="nowrap"><?php echo encode_sensitive($content); ?></td>
  	<td nowrap="nowrap"><?php echo $row['ip']; ?></td>
  	<td nowrap="nowrap"><?php echo $row['addtime']; ?></td>
  	<?php if($option['referer']){ ?><td><?php echo urldecode($row['referer']); ?></td><?php } ?>
  	<?php if($option['agent']){ ?><td><?php echo urldecode(@$row['agent']); ?></td><?php } ?>
  	<td nowrap="nowrap"><button class="btn_h" onclick="v(<?php echo $row['id']; ?>,1);" title="屏蔽后就不提交了">屏蔽</button> <button class="btn_v" onclick="v(<?php echo $row['id']; ?>,0);" title="取消屏蔽">取消</button></td>
  </tr>
<?php } ?>
</table>

<div class="infos">
	<div>说明：黄底红字的行，是此IP此日存在于违禁记录里</div>
	<form action="" method="get">
	共有<b class="red"><?php echo $recordCount; ?></b>个声明&nbsp;
	  <?php if ($page>1){ ?><a href="?page=<?php echo $page-1;?>">上一页</a><?php }?>
	  <?php if ($page<$pageCount) {?><a href="?page=<?php echo $page+1;?>">下一页</a><?php } ?>
	  &nbsp;第<b class="red"><?php echo $page;?></b>/<?php echo $pageCount; ?>页
	  &nbsp;第<input type="text" name="page" size="3" class="input">页 <input type="submit" value="跳转">
	</form>
</div>

<form action="" method="post">
	为防止误点，请先输入数字 8
	<input name="shum" type="text" size="3" maxlength="1">
	<input type="hidden" name="act" value="delete">
	<input type="hidden" name="mtime" value="<?php echo file_exists(DBFILE_TUI) ? filemtime(DBFILE_TUI) : 0; ?>">
	<input type=submit value="清空一切数据" class="button">
</form>
<?php



// ======= 适合提交模式 =======
}else{
	$check_name = array();
	$check_ip = array();
	$emails = array();
	$list = array();
	$numberEnd = null;
	$multiSubmit = array();
	$tj = array();
	$check_date = '';
	$specials = '';
	$firstNames = '';
	$total = 0;
	$splitday = isset($_COOKIE['splitday']) ? intval($_COOKIE['splitday']) : 0;
	$subtotals = isset($_COOKIE['subtotals']) ? intval($_COOKIE['subtotals']) : 0;

	for($i=$number; $i<$recordCount; $i++){
		$row=explode(COLUMN_DELIMITER, trim($rows[$i]));
		foreach($tui_fields as $k=>$v){
			$row[$k] = isset($row[$v])?$row[$v]:'';
		}
		$numberEnd = $row['id'];

		//已屏蔽
		if(in_array($numberEnd, $list_hide)){
			continue;
		}

		//检查测试和重名
		if(strpos($row['name'],'测试')!==false){
			continue;
		}if(in_array($row['name'], $check_name)){
			$numberEnd--;
			break;
		}else{
			$check_name[]=$row['name'];
		}

		//检测日期变更
		$date = explode(' ',$row['addtime']);
		$date = $date[0];
		if($splitday && $check_date && $date!=$check_date){
			$numberEnd--;
			break;
		}else{
			$check_date=$date;
		}

		//记录ip
		$check_ip[$row['ip']][]=$row['name'];

		//提取邮件地址
		if($row['email']) $emails[]=$row['email'];

		//提取内容
		$contentType = intval($row['content']);
		$special = trim($row['special']);
		if($special=='无' || strpos($special,'没有') || preg_match('/^[\w\-\.]+$/', $special)){
			$special = '';
		}
		if($special) $special=preg_replace('#\s+#', '', $special);
		if(!$contentType && !$special) continue;

		//前两个名字
		if(!$firstNames) $firstNames=$row['name']; elseif(strpos($firstNames,"、")===false) $firstNames.="、{$row['name']}";

		if($contentType){
			$total++;
			$content = $content_names[$contentType][0];
			$tj[$contentType] = isset($tj[$contentType]) ? ($tj[$contentType]+1) : 1;
			if($subtotals){
				//分类汇总
				$list[$date][$contentType][] = $row['name'] . ($special?"(备注：{$special})":'');
			}else{
				//不按照组织分类
				$list[] = "{$row['name']}  声明退出{$content}" . ($special?"，{$special}":'') . ($splitday?'':"  {$date}");
			}
		}elseif($special && $subtotals){
			$list[$date]['special'][] = "{$row['name']}(退{$special})";
		}elseif($special && !$subtotals){
			$specials .= "{$row['name']}  退{$special}" . ($splitday?'':"  {$date}") . "\n";
		}
	}

	$content_list = '';
	if($subtotals){
		//分类汇总
		foreach($list as $date=>$rows){
			$special=null;
			$num=0;
			ksort($rows, SORT_NUMERIC);
			foreach($rows as $contentType=>$row){
				if($contentType=='special'){
					$special=implode('，',$row);
				}else{
					$num+=count($row);
					$content_list.="{$content_names[$contentType][1]}： ".implode('  ',$row)."\n";
				}
			}
			if($special) $content_list .= "其他： {$special}\n";
			if($num>0) $content_list .= "共{$num}人\n";
			$content_list .= "{$date}\n\n";
		}
		$content_list = trim($content_list);
	}else{
		//不按照组织分类
		$content_list = implode("\n", $list)."\n";
		$content_list .= "共{$total}人\n";
		if($splitday) $content_list .= "{$check_date}\n";

		if($specials) {
			$content_list .= "\n声明退出共产党其他组织：\n{$specials}";
			if($splitday) $content_list .= $check_date;
		}
	}

	//人数统计
	ksort($tj, SORT_NUMERIC);
	$arr = array();
	foreach($tj as $k=>$v){
		$arr[] = "{$content_names[$k][1]}{$v}人";
	}
	$tj = implode(', ',$arr);

	if(empty($list)){
		echo '<div class="infos">暂时没有需要发表的声明了！</div>';
	}else{
		//检查重复ip
		foreach($check_ip as $ip=>$arr){
			if(count($arr)>1){
				$multiSubmit[] = implode(',', $arr) . '  ' . $ip;
			}
		}
?>
<div class="infos">
	<form action="?" name="xuhao" id="xuhao_form" method="post">
	共有<b class="red"><?php echo $recordCount; ?></b>个声明，
	已发表到第<b class="red"><?php echo $number ?></b>个，
	以下是前<b class="red"><?php echo $total; ?></b>个需要发表的声明（遇到<?php if($splitday){ ?>不同日期的或<?php } ?>重名的就分为一批）。
	<br/>
	<input name="xuh" type="hidden" value="<?php echo $numberEnd; ?>" >
	<input type="hidden" name="act" value="xuhao">
	<div>
	<input type="checkbox" id="splitday" <?php if($splitday) echo "checked='checked'"?> />遇到不同日期就分批
	&nbsp;&nbsp;<input type="checkbox" id="subtotals" <?php if($subtotals) echo "checked='checked'"?> />按照组织名称分类汇总
	</div>
	<input onclick="return confirmXuhao();" type="submit" id="btn_post" value="标记最后发表的声明序号为<?php echo $numberEnd; ?>，并显示下一批">
	</form>
</div>

<h2 id="tit" style="margin:20px 0 5px 0;">
	声明总人数：<b class="red" id="t_total"><?php echo $total; ?></b>
</h2>
<table id="tbltui" border="0" cellpadding="1" align="left" width="100%" >
<form method="POST" id="frmtui" action="http://tuidang.epochtimes.com/post/"
target="_blank" accept-charset="utf-8" onsubmit="document.charset='utf-8';">
<tbody>
	<tr><td align="left" width="40" nowrap>姓名：</td><td><input type="text" name="name" size="50" value="<?php echo $firstNames . ($total>2?"，等{$total}人":'') ?>" /></td></tr>
	<tr><td align="left">标题：</td><td><input type="text" name="subject" size="50" value="声明退出共产党和共产党其它组织"></td></tr>
	<tr><td align="left">人数：</td><td><input type="text" name="smnumber" size="5" value="<?php echo $total; ?>"> <span class="tips">未包含只退其他组织的；分类统计：<?php echo $tj; ?></span></td></tr>
	<tr><td align="left" valign="top">内容：</td><td><textarea class="list" id="list" name="content"><?php echo $content_list;?></textarea></td></tr>
	<tr><td>&nbsp;</td><td>
<button onclick="copytui(); return false;">复制列表</button>&nbsp;
<input type="submit" value="发表到大纪元退党网站" onclick="return confirmSubmit();" />&nbsp;
<button onclick="{$('btn_post').click(); return false;}">标记最后发表的声明序号为<?php echo $numberEnd; ?>，并显示下一批</button>&nbsp;
</td></tr>
</tbody>
<input type="hidden" name="smallcategoryid" value="30">
<input type="hidden" name="email" value="">
<input type="hidden" name="address" value="">
</form>
<div class="clear"></div>
</table>

<div class="dialog dialog0" id="dialog">
	<div class="dialog_co">
		<strong>提交后记得标记</strong>
		<div class="co">已经成功提交了吗？<br/>提交到大纪元之后，需要标记最后发表的声明序号。</div>
		<div class="btns"><button onclick="$('dialog').style.display='none';"> 知道了 </button></div>
	</div>
	<div class="dialog_bg"></div>
</div>

<script type="text/javascript">
var e=$('list');
var h=e.scrollHeight;
if(h>0) {
	if(h>300) h=300;
	e.style.height=h+'px';
}else{
	e.rows=5;
}

$('splitday').onclick=function(){
	document.cookie='splitday=' + (this.checked?1:0);
	location.href='?style=submit';
};
$('subtotals').onclick=function(){
	document.cookie='subtotals=' + (this.checked?1:0);
	location.href='?style=submit';
};

function copytui() {
  var s=$('list').value.replace(/\n/g,"\r\n");
  if (window.clipboardData) {
    window.clipboardData.setData("Text", s);
	alert("已经复制到剪贴板！");
  } else {
	alert("浏览器不支持，请使用IE，或手动复制！");
  }
}

function confirmSubmit(){
	if(confirm('确实要发表到大纪元吗？\n请在保证网络安全的情况下提交！')){
		//$("dialog").style.display="block";
		return true;
	}else{
		return false;
	}
}

function confirmXuhao(){
	return (confirm('上述声明都已发表了吗？\n只有在发表后才能進行标记！'));
}
</script>

<div class="infos" style="clear:both; margin-top:10px;">
	<?php if(!empty($multiSubmit)){?>
		<h3 style="margin-top:20px;">IP地址重复的申请为：</h3>
		<?php echo implode("<br/>", $multiSubmit) ?>
	<?php }?>

	<?php if(!empty($emails)){?>
		<h3 style="margin-top:20px;">涉及到的email列表为：</h3>
		<?php echo implode("<br/>", $emails) ?>
	<?php }?>
</div>

<?php }}?>

<?php foot("<iframe id='_hiddenframe' width='0' height='0' scrolling='no' border='0' style='display:none;'>"); ?>
