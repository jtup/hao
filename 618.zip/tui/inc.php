<?php
defined('DEBUGING') or define('DEBUGING', 0);
define('APP_CHARSET', 'UTF-8');
define('DIR', dirname(__FILE__));
define('DATADIR', DIR);
define('PARENT_DIR', dirname(DIR));
define('INCLUDE_DIR', file_exists(PARENT_DIR.'/include/http.inc.php') ? (PARENT_DIR.'/include') : DIR);
define('DBFILE_TUI', DATADIR."/~data_tui.txt");
define('DBFILE_TUI_DONE', DATADIR."/~data_done.txt");
define('DBFILE_TUI_FABIAO', DATADIR."/~data_fabiao.txt");
define('DBFILE_TUI_LOG', DATADIR."/~data_log.txt");
define('DBFILE_TUI_HIDE', DATADIR."/~data_hide.txt");
define('DBFILE_TUI_BLOCKED', DATADIR."/~data_blocked.txt");
define('DBFILE_TUI_NUMBER', DATADIR."/~data_number.txt");
define('DBFILE_LOGIN', DATADIR."/~data_login.txt");
define('DBFILE_VISIT', DATADIR."/~data_visit.txt");
define('COLUMN_DELIMITER', '|@|');	//文本型数据文件的列分隔符（行分隔符是\n）
define('COOKIE_COUNTER', '3t_v'); //访问统计参数
define('COOKIE_REFERER', '3t_rf');
define('COOKIE_BLOCKED', '3t_lk');
define('COOKIE_IKNOW', '3t_lkn');
header('Content-Type: text/html; charset='.APP_CHARSET);
error_reporting(DEBUGING ? E_ALL | ~E_NOTICE : E_ERROR);
date_default_timezone_set('Asia/Shanghai');

if(!function_exists('mb_convert_encoding')) exit('必需支持 mb_convert_encoding 函数库');
if(!include(INCLUDE_DIR.'/global.inc.php')) exit('没找到 global.inc.php 文件');
if(!include(INCLUDE_DIR.'/http.inc.php')) exit('没找到 http.inc.php 文件');

//使用主程序（上级目录的）里所设置的管理密码
require(DIR.'/config.inc.php');
if(empty($config_admin_password) && file_exists(PARENT_DIR.'/config.inc.php')){
    include(PARENT_DIR.'/config.inc.php');
    $config_admin_password = !empty($config['password']) ? $config['password'] : '';
}

//禁止所有蜘蛛访问
if(Http::isSpider()){
    header('HTTP/1.0 403 Forbidden');
    exit('403 Forbidden');
}



$isPost = !empty($_POST);
$act = isset($_GET['act']) ? $_GET['act'] : (isset($_POST['act']) ? $_POST['act'] : '');


//列序号
$tui_fields = array(
	'status' => 0,
	'id' => 1,
	'name' => 2,
	'email' => 3,
	'ip' => 4,
	'addtime' => 5,
	'referer' => 6,
	'content' => 7,
	'special' => 8,
	'agent' => 9,
	'hash' => 10,
);



// ====================================================================================================================

/**
 * 页头
 */
function head($title, $other_head=null){
	static $head_written=false;
	if($head_written) return; else $head_written=true;
	global $config_topnav;
	$nav = $config_topnav ? (' | '.$config_topnav) : '';
	echo <<<EOF
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<title>{$title}</title>
<link href="css.css" rel="stylesheet" type="text/css" />
{$other_head}
</head>
<body>
<div id="main">
EOF;
}

/**
 * 页脚
 */
function foot($str=''){
	echo "{$str}</div></body></html>";
}

/**
 * 检查email合法性
 */
function checkemail($email, $require=false) {
	$email = trim(strtolower($email));
	if($require && !$email){
		return "Email不能为空!<br/>";
	}elseif($email && !preg_match('/^[\w\.\-]+@[\w\.\-]+\.[a-z]{2,4}$/', $email)) {
		return "Email格式不正确!<br/>";
	}else{
		return;
	}
}

/**
 * 检查内容合法性
 * @return string 内容合法则返回空值，否则返回错误信息
 */
function checkcontent(&$content, $fieldName='提交内容', $min=8, $max=1000, $checkf=true, $pattern=null) {
	global $config_noword, $warning_text, $referer;

	$len = mb_strlen($content, 'utf-8');
	if ($len==0 && $min>0) {
		return "{$fieldName}不能为空!<br/>";
	}elseif ($min>0 && $len<$min) {
		return "{$fieldName}起码也要{$min}个字符!<br/>";
	}elseif ($max>0 && $len>$max) {
		return "{$fieldName}不能超过{$max}个字符!<br/>";
	}elseif (preg_match ( '/[<>\'"]/', $content )) {
		return '{$fieldName}中不能包含 <>\'" 等特殊字符!<br/>';
	}
	$content = str_replace(COLUMN_DELIMITER, '', $content);
	if(empty($content)) return;

	static $noword=null;
	if($noword===null){
		$arr = explode('|',$config_noword);
		foreach($arr as $k=>$v){
			if(empty($v)){
				unset($arr[$k]);
			}else{
				$arr[$k]=preg_quote($v);
			}
		}
		$noword='/('.implode('|',$arr).')/';
	}

	$blocked = false;
	if($checkf){
		$blocked = (strpos($content,'志')!==false && strpos($content,'李')!==false && strpos($content,'洪')!==false) ||
			(strpos($content,'轮')!==false && strpos($content,'法')!==false);
	}
	if(!$blocked && $noword){
		$blocked = preg_match ( $noword, $content );
	}
	if(!$blocked && $pattern){
		$blocked = !preg_match ( $pattern, $content );
	}

	if ($blocked){
		//while(strlen($content)<20) $content.='　';
		$contents = '时间: '.date('Y-m-d h:i:s',time()) .
			//"\t{$fieldName}：{$content}" .
			"\tIP: ".get_ip() .
			"\t来源: ". str_replace('<br/>',', ',$referer).
			//"\t\t{$fieldName}: {$content}".
			"\r\n";
		file_put_contents(DBFILE_TUI_BLOCKED, $contents, FILE_APPEND);
		setcookie(COOKIE_BLOCKED,'1',time()+3600*24);
		if(!$warning_text){
			$warning_text = '可能含有敏感词，请文明用语！';
		}
		head('请一定要珍惜自己！');
		echo encode_sensitive($warning_text);
		foot();
		exit;
	}

	return null;
}

/**
 * 检查ip地址是否被禁
 */
function checkip() {
	global $config_noip;
	if (preg_match('/^('.str_replace($config_noip,'.','\\.').')/', get_ip())) {
		exit('禁止提交！');
	}
}

/**
 * 换行标签转换为换行符
 */
function br2nl($str) {
	return str_replace ( array('<br>','<br/>','<br />','<br  />'), "\n", $str );
}

/**
 * 出错页面
 */
function error($error, $url='./') {
	head('出错了');
	echo <<<EOF
<h2>发生错误： </h2>
<p>{$error}</p>
<p>
	<a href="{$url}">请点击这里返回!</a>
</p>
EOF;
	foot();
	exit ();
}

/**
 * 成功页面
 */
function isok($msg, $url='') {
	$url = $url?$url:$_SERVER['HTTP_REFERER'];
	head('成功');
	echo <<<EOF
<h2>成功：{$msg}</h2>
<p>
	<a target="_parent" href="{$url}">请点击这里返回!</a>
</p>
EOF;
	foot();
	exit ();
}

/**
 * 成功并跳转页面
 */
function isoka($msg, $url='') {
	$url = $url?$url:$_SERVER['HTTP_REFERER'];
	head('成功', '<meta HTTP-EQUIV="REFRESH" CONTENT="2; URL='.$url.'">');
	echo <<<EOF
<h2>成功：{$msg}</h2>
<p>
	<a href="{$url}">两秒钟后将自动返回... 点击这里立即返回! </a>
</p>
EOF;
	foot();
	exit ();
}

//检查用户提交的数据
function checkuser(&$user) {
	$user = trim($user);
	$result = checkcontent($user, '名字', 2, 10);
	if($result){
		return $result;
	}elseif (preg_match( '#[^\x{4e00}-\x{9fa5}]#u', $user )) {
		return "名字只能包含汉字!<br/>";
	}
}

//成功并跳转页面
function isok_3t($msg) {
	head('成功');
	$url = './';
	if(isset($_GET['inframe'])) $url.='?inframe='.$_GET['inframe'];
	echo "<h2>成功：{$msg}</h2><p><a href='{$url}'>继续提交其他人的声明</a>&nbsp;" .
		((!defined('IN_FRAME') || IN_FRAME==0) ? "<a href='/?home' id='gotohome' noproxy>返回首页</a>" : '') .
		"</p><img border='0' src='fu.jpg' width='138' height='200'>";
	foot();
}

function get_name_options(){
	global $config_names_test, $config_names, $config_name_words1, $config_name_words2;
	$ret = '';
	if(!empty($config_names_test)){
		$arr = explode('|', $config_names_test);
		foreach($arr as $v){
			$ret .= "<option value=\"{$v}\">{$v}</option>";
		}
	}

	$names = array();

	//使用预置昵称
// 	$names = explode('|', $config_names);

	//生成50个男士名字和50个女士名字
	$arr1 = explode('|', $config_name_words1);
	shuffle($arr1);
	$arr2 = explode('|', $config_name_words2);
	shuffle($arr2);
	$arr = array_merge(array_slice($arr1, 0, 100), array_slice($arr2, 0, 100));
	for($i=0, $count=count($arr); $i<$count-1; $i+=2){
		$names[] = $arr[$i].$arr[$i+1];
	}

	shuffle($names);
	$names = array_slice($names, 0, 100);
	foreach($names as $v){
		$ret .= "<option value=\"{$v}\">{$v}</option>";
	}
	return $ret;
}

function start_frontend(){
	global $warning_text, $referer, $config_text;

	//检查是否被屏蔽
	if(!empty($_COOKIE[COOKIE_BLOCKED])){
		head('请一定要珍惜自己！');
		echo encode_sensitive($warning_text);
		foot();
		exit;
	}

	//访问统计
	if(isset($_GET[COOKIE_COUNTER])){
		if(!isset($_COOKIE[COOKIE_COUNTER])){
			if(record_counter(DBFILE_VISIT)){
				//写入cookie，避免重复计数
				setcookie(COOKIE_COUNTER, 1);
			}
		}
		header('Content-Type: image/png');
		exit;
	}

	//记录来源页面和客户端类型
	if(!isset($_COOKIE[COOKIE_REFERER])){
		updateTuiStatics();

		$url = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		$x = strpos($url, '?');
		if($x>0) $url = substr($url, 0, $x);

		if(empty($_SERVER["HTTP_REFERER"])){
			$referer='';
		}else{
			$referer=$_SERVER["HTTP_REFERER"];
			$referer=strtr($referer,'<>()\'"','         ');
			$referer=substr($referer,0,200);
		}
		setcookie(COOKIE_REFERER, urlsafe_base64_encode($url . ($referer?"<br/>$referer":'')));
	}else{
		$referer=urlsafe_base64_decode($_COOKIE[COOKIE_REFERER]);
	}

	$config_text = file_get_contents(DBFILE_TUI_NUMBER) . $config_text;
}

/**
 * 提交表单
 * @return 如果失败就直接输出错误信息并终止页面，如果成功就返回成功提示信息
 */
function do_submit(){
	global $referer;

	//检查ip地址是否被禁
	checkip();

	$realip = get_ip ();
	$today = date ( "Ymd" );
	$tmpcheck = "$today $realip ";
	$currentHash = substr(md5("{$_POST['select']}, {$_POST['namecc']}, {$_POST['email']}, {$_POST['content']}, {$_POST['special']}"),8,16);

	$lines = file_exists(DBFILE_TUI_DONE) ? file(DBFILE_TUI_DONE) : array();
	$tmp1 = 0;
	$row = end($lines);
	while($row!==false){
		if(substr($row,0,8)!=$today) break;
		if (strpos($row, $tmpcheck )===0) {
			$tmp1 ++;
			if ($tmp1 >= 5) {
				error ( '您今天提交的声明很多了，请明天再继续提交吧 :)');
			}
			if (strpos($row, $currentHash)!==false) {
				return '';
			}
		}
		$row=prev($lines);
	}

	$namecc = isset ( $_POST ['select'] ) ? $_POST['select'] : '';
	if (! $namecc || $namecc == "0") {
		$namecc = isset ( $_POST ['namecc'] ) ? $_POST ['namecc'] : '';
	}
	$email = isset ( $_POST ['email'] ) ? $_POST ['email'] : '';
	$content = isset ( $_POST ['content'] ) ? $_POST ['content'] : '';
	$special = isset ( $_POST ['special'] ) ? $_POST ['special'] : '';
	$addtime = date ( "Y-m-d H:i:s" );

	$result = '';
	$result .= checkuser ( $namecc );
	$result .= checkemail ( $email );
	$result .= checkcontent ( $content, '组织名称', 0, 100, true, '#^[123]{1,3}$#' );
	$result .= checkcontent ( $special, '其它备注', 0, 100 );
	if(trim($content)=="" && trim($special)==""){
		$result.="“组织名称”和“其它备注”至少要填写一项！<br/>";
	}

	if ($result) {
		error ( $result, '?' );
	}

	$referer=urlencode($referer);
	$agent=!empty($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : '';
	$agent=strtr($agent,'<>()\'"','         ');
	$agent=substr($agent,0,200);
	$agent=urlencode($agent);

	$fp = fopen_safe(DBFILE_TUI, $temp);
	if($fp===false){
		error('写入信息时出错！请稍后从新提交！');
	}
	$tail_str = substr($temp,-512*10);
	$tail_lines = $tail_str ? explode("\n", trim($tail_str)) : array();

	$found = false;
	$i = 0;
	$row = end($tail_lines);
	while($row!==false && $i++<5){
		if(substr($row,-16)==$currentHash){
			$found = true;
			break;
		}
		$row=prev($tail_lines);
	}

	$err = '';
	if(!$found){
		$row = end($tail_lines);
		if($row){
			$arr=explode(COLUMN_DELIMITER, $row, 3);
			$num=$arr[1]+1;
		}else{
			$num=1;
		}
		$all = "0{COLUMN_DELIMITER}$num{COLUMN_DELIMITER}$namecc{COLUMN_DELIMITER}$email{COLUMN_DELIMITER}$realip{COLUMN_DELIMITER}$addtime{COLUMN_DELIMITER}{$referer}{COLUMN_DELIMITER}$content{COLUMN_DELIMITER}$special{COLUMN_DELIMITER}$agent{COLUMN_DELIMITER}$currentHash\n";
		$all = str_replace('{COLUMN_DELIMITER}', COLUMN_DELIMITER, $all);
		if($tail_str && substr($tail_str,-1)!="\n") $all="\n".$all;

		fseek($fp, 0, SEEK_END);
		if(fwrite($fp, $all, strlen($all))<strlen($all)) {
			$err = '写入信息时出错！请稍后从新提交！';
		}else{
			file_put_contents(DBFILE_TUI_DONE, "$tmpcheck $currentHash\n", FILE_APPEND);
		}
	}

	flock($fp, LOCK_UN);
	fclose($fp);

	if($err){
		error($err);
	}else{
		//isok_3t ( "数据提交成功！衷心祝福您有一个美好的未来！" );
		//exit;
	    setcookie(COOKIE_IKNOW, 1);
		return "<div id='success'>
			<h2>数据提交成功，义工将尽快帮您提交到大纪元退党网！衷心祝福您有一个美好的未来！</h2>
			<img border='0' src='fu.jpg' onload=\"if(document.body.offsetWidth<600 && document.body.offsetWidth<document.body.offsetHeight) this.style.width='100%';\" />
			</div>";
	}
}

/**
 * 自动采集三退人数，结果保存到config.inc.php里，每天只采集一次
 */
function updateTuiStatics(){
	$ip = $_SERVER['SERVER_ADDR'];
	if(strpos($ip,'127.0.')===0 || strpos($ip,'192.168.')===0) return;

	if(date('d')!=date('d', filemtime(DBFILE_TUI_NUMBER))){
		touch(DBFILE_TUI_NUMBER);
		$config=array('proxy'=>'');
		$ret=array();
		$html=http_get('http://tuidang.epochtimes.com/stat/statics');
		$xml=new SimpleXMLElement($html);
		if(isset($xml->TIME->LASTUPDATE) && isset($xml->NUMBER->TOTAL)){
			$time = $xml->TIME->LASTUPDATE;
			$time = preg_replace('#^(\d{4})-(\d+)-(\d+).+#', '\\1年\\2月\\3日', $time);
			$total = $xml->NUMBER->TOTAL;
			if(strlen($total)==11){
				file_put_contents(DBFILE_TUI_NUMBER, "至{$time}，共有<b>{$total}</b>人");
			}
		}
	}
}

function if_android($true, $false){
    return stripos($_SERVER['HTTP_USER_AGENT'],'android')>0 ? $true : $false;
}
