<?php
/**
 * 3退提交表单
 *
 */

define('DEBUGING', 0);
require('inc.php');

$successMsg = $referer = '';
start_frontend();
if ($isPost && $act=="提交") {
    $successMsg = do_submit();
}

head($config_title);
?>
<script type="text/javascript">
function $v(id){return document.getElementById(id).value;}
function change_unit(obj){document.getElementById('namecc').style.display = obj.options.selectedIndex<=0?"":"none";}
function checkform(f){
var n=$v('select')?$v('select'):$v('namecc'), c=$v('content'), s=$v('special');
if(!n){alert('请选择或输入名字！'); return false;}
if(!c && !s){alert('“组织名称”和“其它备注”至少要填写一项！'); return false;}
if(s.indexOf("\u6CD5")!=-1 && s.indexOf("\u8F6E")!=-1) {alert("“其它备注”里只能输入中\u5171组织名称"); return false;}
<?php if(isset($_COOKIE[COOKIE_IKNOW]) || $successMsg){ ?>
if(!f.iknow.checked){alert('代替他人声明需本人同意！'); return false;}
<?php } ?>
return true;
}
function closeAlert(c){
	if(c===1) document.cookie='_hide_alert_=1';
	else if(c===2) document.cookie='_hide_alert_=1' + (new Date(2050,1,1)).toGMTString();
	document.getElementById('dialog').style.display='none';
}
if(location.pathname=='/tui') location.assign('/tui/');
</script>
<style type="text/css">#news, #help1 {background-color:<?php echo $bgcolor; ?>;}</style>

<?php echo $successMsg; ?>

<h1>&#25552;&#20132;&#19977;<nzj1></nzj1>&#36864;<bnyy7></bnyy7>&#22768;&#26126;</h1>
<div id="news"><?php echo encode_sensitive($config_text); ?></div>

<form action="./<?php if(isset($_GET['inframe'])) echo '?inframe='.$_GET['inframe']; ?>" id="frmAdd" method="post">
<div class="row"><label for="select">您的名字：</label><select id="select" name="select" size="1" onchange="change_unit(this)"><option value="">自己输入</option>
	<?php echo get_name_options();?>
	</select><input type="TEXT" id="namecc" name="namecc" size="10" maxlength="4" class="input">
</div>
<div class="row">
	<label for="content">组织名称：</label><select id="content" name="content" size="1">
	<option value=""></option>
	<option value="1"><vejk7></vejk7>&#20849;<dzhpn5></dzhpn5><xf3></xf3>&#20135;<m6></m6><g7></g7>&#20826;<feah6></feah6></option>
	<option value="2"><vv0></vv0>&#20849;<l1></l1>&#38738;&#22242;</option>
	<option value="3">&#23569;&#20808;&#38431;</option>
	<option value="12"><oqznh6></oqznh6>&#20849;<b8></b8><ypb0></ypb0>&#20135;<ffv5></ffv5><vod1></vod1>&#20826;<f3></f3>&#21644;<mqr8></mqr8>&#20849;<q5></q5>&#38738;&#22242;</option>
	<option value="23"><ho3></ho3>&#20849;<lxrw0></lxrw0>&#38738;&#22242;&#21644;&#23569;&#20808;&#38431;</option>
	<option value="13"><exur8></exur8>&#20849;<wv7></wv7><fm0></fm0>&#20135;<scgfg7></scgfg7><q3></q3>&#20826;<mq0></mq0>&#21644;&#23569;&#20808;&#38431;</option>
	<option value="123"><sl4></sl4>&#20849;<jc4></jc4><fp4></fp4>&#20135;<zcuhx9></zcuhx9><jjud7></jjud7>&#20826;<bojz0></bojz0>&#12289;<pbqpc5></pbqpc5>&#20849;<cb8></cb8>&#38738;&#22242;&#21644;&#23569;&#20808;&#38431;</option>
	</select><span class="tips">（&#27880;&#24847;&#65306;&#36864;&#22242;&#12289;&#36864;&#38431;&#21253;&#25324;&#24050;&#32463;&#36229;&#40836;&#30340;&#22242;&#21592;&#12289;&#38431;&#21592;）</span>
</div>
<div class="row"><label for="email">电子邮件：</label><input type="text" id="email" name="email" size="20" maxlength="50" class="input"><span class="tips">（可选）</span><br/></div>
<div class="row"><label for="special">其它备注：</label><input type="text" id="special" name="special" size="20" maxlength="9" class="input"><span class="tips">（可选）</span><br/></div>
<?php if(isset($_COOKIE[COOKIE_IKNOW]) || $successMsg){ ?>
<div class="row"><label for="iknow">重要提示：</label><input type="checkbox" id="iknow" name="iknow" value="1">我已知道“代替他人声明需本人同意”<br/></div>
<?php } ?>
<div class="row">
<button type="submit" name="act" value="提交" class="button" style="margin:10px 0; width:100%;"
onclick="return checkform(this.form);">提交到大纪元退党网</button>
</div>
</form>

<div id="help1">
&#24744;&#21487;&#33021;&#35828;&#25105;&#20063;&#30693;&#36947;&#23427;&#19981;&#22909;&#65292;&#24605;&#24819;&#20013;&#26089;<j3></j3>&#36864;<nmdvo4></nmdvo4>&#20102;&#25110;&#24050;&#36229;&#40836;&#12290;&#20294;&#37027;&#37117;&#19981;&#31639;&#25968;&#65292;&#22240;&#20026;&#22312;&#37027;&#20010;&#34880;&#26071;&#21069;&#38754;&#23545;&#22825;&#21457;&#27602;&#35475;&#26102;&#65292;&#26159;&#35828;&#35201;&#25226;&#29983;&#21629;&#21644;&#19968;&#20999;&#37117;&#36129;&#29486;&#32473;<tu3></tu3>&#37034;<wy6></wy6><k4></k4>&#20826;<x3></x3>&#65292;&#25152;&#20197;&#21482;&#26377;&#37319;&#21462;&#20844;&#24320;&#30340;&#24418;&#24335;&#65288;&#21487;&#29992;&#21270;&#21517;&#65289;&#12289;&#26377;&#34892;&#20026;&#30340;&#34920;&#31034;&#65292;&#25165;&#33021;&#38500;&#25481;&#36825;&#20040;&#22823;&#30340;&#27602;&#35475;&#65292;&#25165;&#33021;&#22312;&#22825;<sqnl9></sqnl9>&#28781;<sgpt4></sgpt4>&#20013;<ggg4></ggg4>&#20849;<cfy7></cfy7>&#30340;&#26102;&#20505;&#20445;&#24179;&#23433;&#65281;</div>

<div id="help2">
<b>&#34920;&#21333;&#22635;&#20889;&#35828;&#26126;&#65306;</b><br/>
&nbsp;&nbsp;1. &ldquo;&#24744;&#30340;&#21517;&#23383;&rdquo;&#21487;&#20197;&#33258;&#24049;&#36755;&#20837;&#24744;&#30340;<vvp3></vvp3>&#30495;<qou8></qou8>&#23454;&#22995;&#21517;&#25110;&#32773;&#19968;&#20010;&#21270;&#21517;&#12289;&#20195;&#31216;&#65288;&#24517;&#39035;&#20351;&#29992;&#27721;&#23383;&#65292;&#26368;&#22810;&#21487;&#36755;&#20837;&#22235;&#20010;&#23383;&#65289;&#65292;&#20063;&#21487;&#20197;&#22312;&#19979;&#25289;&#21015;&#34920;&#20013;&#36873;&#25321;&#19968;&#20010;&#24744;&#21916;&#27426;&#30340;&#21270;&#21517;&#12290;&#20294;&#19981;&#35201;&#20351;&#29992;&#23383;&#27597;&#25110;&#25340;&#38899;&#65292;&#20195;&#20154;&#22768;&#26126;&#39035;&#26412;&#20154;&#24895;&#24847;<br/>
&nbsp;&nbsp;2. 请在“组织名称”的下拉列表中选择您要<o6></o6>&#36864;<zdj2></zdj2>出的<vyf5></vyf5>&#20849;<e7></e7><se5></se5>&#20135;<ddhc8></ddhc8><metp5></metp5>&#20826;<uqob8></uqob8>组织。如果您以前参加过<lhgqu0></lhgqu0>&#32418;<c3></c3>小兵、<svjq1></svjq1>&#32418;<jzt5></jzt5>卫兵等其它<mg6></mg6>&#20849;<yb1></yb1><xpm8></xpm8>&#20135;<g6></g6><bmc3></bmc3>&#20826;<tqqh3></tqqh3>组织，请写入“其它备注”一项，此项最多可输入九个汉字。<br/>
&nbsp;&nbsp;3. 如果您输入了一个有效的Email地址，我们会将您的三<dfbt3></dfbt3>&#36864;<as6></as6>证书查询密码发送到您的信箱中,以便于您以后登录海外<ssxz3></ssxz3>&#36864;<d9></d9><fcl2></fcl2>&#20826;<igcz0></igcz0>网站查询三<pwn1></pwn1>&#36864;<trsv5></trsv5>信息及获取证书。如果没有输入Email地址，请您记住提交声明的时间和使用的名字，以便将来必要时用来验证您的三<yj2></yj2>&#36864;<b1></b1>声明。<br/>
</div>

<div class="dialog dialog1" id="dialog">
	<div class="dialog_co">
		<strong>提示</strong>
		<div class="co">请下载文件到本地，随时保持畅通浏览&#31105;<iic></iic>&#32593;</div>
		<div class="btns"><a class="btn" onclick="closeAlert(0);" href="<?php echo $download_file; ?>" noproxy>下载最新&#32763;&#22681;软件</a>
		<button class="btn btn_gray" onclick="closeAlert(1);">不再显示</button></div>
	</div>
	<div class="dialog_bg" onclick="closeAlert(0);"></div>
</div>
<script type="text/javascript">
if(!document.cookie || document.cookie.indexOf('_hide_alert_=1')===-1){
	document.getElementById('dialog').style.display='block';
}
</script>

<?php
if(!isset($_COOKIE[COOKIE_COUNTER])) echo '<img src="?'.COOKIE_COUNTER.'=1" width="0" height="0" style="display:none" />';
foot();
?>
