<?php
/**
 * 3退提交表单
 */

define('DEBUGING', 0);
require('inc.php');

$successMsg = $referer = '';
start_frontend();

if ($isPost && $act=="提交") {
	$successMsg = do_submit();
}

?>
<!DOCTYPE html><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<title><?php echo $config_title; ?></title>
<link href="css2.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var istest=0,mp3='chat.mp3',stage_pos=[153,163,172],stage=0;var currentTime=getCookie('audpos');if(currentTime=='end'){stage=4}else{currentTime=parseInt(currentTime,10);if(isNaN(currentTime)||currentTime<0)currentTime=0}function $(id){return document.getElementById(id)}function change_unit(id){obj=$(id);obj.style.color=obj.options.selectedIndex<=0?"#999":"";if(id=='select'){$('namecc_p').style.display=obj.options.selectedIndex<=0?"":"none"}}function checkword(s){if(s.indexOf("\u6CD5")!=-1&&s.indexOf("\u8F6E")!=-1){alert("“其它备注”里只能输入中\u5171组织名称");return false}else return true}function getCookie(aName){var sSearch=" "+aName+"=";var acookie=" "+document.cookie+";";if(acookie.length>0){var iOffset=acookie.indexOf(sSearch);if(iOffset!=-1){iOffset+=sSearch.length;var iEnd=acookie.indexOf(";",iOffset);if(iEnd==-1){iEnd=acookie.length}acookie=acookie.substring(iOffset,iEnd);return unescape(acookie)}}return null}function aud_start(){$('ring').style.display='none';$('btn_pause').style.display='block';$('btn_resume').style.display='none';$('playing').style.display='block';$('some_input').style.display='block';aud.play()}function aud_canplay(){if(currentTime){aud.currentTime=currentTime;currentTime=0}}function aud_started(){$('ring').style.display='none';$('btn_pause').style.display='block';$('btn_resume').style.display='none';$('playing').style.display='block';$('some_input').style.display='block'}function aud_end(played){$('loading').style.display='none';$('main').style.display='none';$('more_input').style.display='block';if(played){var v="",tables={"1":1,"2":2,"3":3,"12":4,"23":5,"13":6,"123":7};if($('ru_3').checked)v+="1";if($('ru_2').checked)v+="2";if($('ru_1').checked)v+="3";v=v===""?0:tables[v];$('content').options[v].selected=true;change_unit('content')}if(istest==0)document.cookie='audpos=end'}function aud_pause(){aud.pause();$('btn_pause').style.display='none';$('btn_resume').style.display='block'}function aud_resume(){aud.play();$('btn_pause').style.display='block';$('btn_resume').style.display='none'}function aud_progress(currentTime,duration){var percentPlayed=Math.round(aud.currentTime/aud.duration*100);if(stage<3&&currentTime>=stage_pos[stage]){stage++;if(istest==0)document.cookie='audpos='+(currentTime-2)+'; path=/';$('ru_'+stage+'_p').style.display='block'}}function domReady(){change_unit('select');change_unit('content');if(stage==0){$('loading').style.display='none';$('main').style.display='block';var aud=$('aud');aud.src=mp3;aud.loop=false;aud.autoplay=false;aud.isLoadedmetadata=false;aud.touchstart=false;aud.audio=true;aud.autobuffer=true;aud.load();aud.addEventListener('canplay',function(evt){aud_canplay()});aud.addEventListener('playing',function(evt){aud_started()});aud.addEventListener('ended',function(evt){aud_end(true)});aud.addEventListener('timeupdate',function(evt){aud_progress(aud.currentTime,aud.duration)})}else{aud_end(false)}}
</script>
</head>
<body>

<noscript>
<style type="text/css">
#ring, #playing, #some_input, #aud, #loading{display:none;}
#more_input{display:block;}
</style>
</noscript>

<div id="loading">loading ...</div>

<div id="main">
	<div id="ring">
		<p><img src="ring.gif" />请求交谈</p>
		<button class="color green" onclick="aud_start(); return false;">好！开始通话吧</button>
		<button class="color gray" onclick="aud_end(false); return false;">暂时不方便语音</button>
	</div>

	<div id="playing">
		<button id="btn_pause" class="color gray" onclick="aud_pause();">请暂停一下</button>
		<button id="btn_resume" class="color green" onclick="aud_resume();">请继续</button>
	</div>

	<div id="some_input">
		<p id="ru_1_p"><input type="checkbox" id="ru_1" value="3" />你带过&#32418;领巾吗？ </p>
		<p id="ru_2_p"><input type="checkbox" id="ru_2" value="2" />入过团吗？ </p>
		<p id="ru_3_p"><input type="checkbox" id="ru_3" value="1" />你是&#20826;员吗？ </p>
	</div>
</div>

<form id="more_input" action="" method="post">
<fieldset>
	<?php echo $successMsg; ?>

	<h1>提交三<nzj1></nzj1>&#36864;<bnyy7></bnyy7>&#22768;&#26126;</h1>

	<div class="row"><div class="content"><?php echo encode_sensitive($config_text); ?></div></div>

    <p class="row">
      <label for="select" class="select">
		<select id="select" name="select" size="1" onchange="change_unit('select')">
		<option value="">请在下边输入姓名（也可在此选择&#21270;&#21517;）</option>
		<?php echo get_name_options();?>
		</select>
      </label>
    </p>

    <p class="row" id="namecc_p">
      <input type="text" name="namecc" size="10" maxlength="4" id="namecc_input" placeholder="姓名、小名或&#21270;&#21517;（代人&#22768;&#26126;须本人愿意）" />
    </p>

    <p class="row">
      <label for="select" class="select" onchange="change_unit('content')">
		<select id="content" name="content" size="1">
		<option value="">选择您要<o6></o6>&#36864;<zdj2></zdj2>出的<vyf5></vyf5>&#20849;<e7></e7><se5></se5>&#20135;<ddhc8></ddhc8><metp5></metp5>&#20826;<uqob8></uqob8>组织</option>
		<option value="1"><vejk7></vejk7>&#20849;<dzhpn5></dzhpn5><xf3></xf3>&#20135;<m6></m6><g7></g7>&#20826;<feah6></feah6></option>
		<option value="2"><vv0></vv0>&#20849;<l1></l1>&#38738;&#22242;</option>
		<option value="3">&#23569;&#20808;&#38431;</option>
		<option value="12"><oqznh6></oqznh6>&#20849;<b8></b8><ypb0></ypb0>&#20135;<ffv5></ffv5><vod1></vod1>&#20826;<f3></f3>&#21644;<mqr8></mqr8>&#20849;<q5></q5>&#38738;&#22242;</option>
		<option value="23"><ho3></ho3>&#20849;<lxrw0></lxrw0>&#38738;&#22242;&#21644;&#23569;&#20808;&#38431;</option>
		<option value="13"><exur8></exur8>&#20849;<wv7></wv7><fm0></fm0>&#20135;<scgfg7></scgfg7><q3></q3>&#20826;<mq0></mq0>&#21644;&#23569;&#20808;&#38431;</option>
		<option value="123"><sl4></sl4>&#20849;<jc4></jc4><fp4></fp4>&#20135;<zcuhx9></zcuhx9><jjud7></jjud7>&#20826;<bojz0></bojz0>&#12289;<pbqpc5></pbqpc5>&#20849;<cb8></cb8>&#38738;&#22242;&#21644;&#23569;&#20808;&#38431;</option>
		</select>
      </label>
    </p>

    <p class="row">
      <input type="text" name="email" size="20" maxlength="50" id="email_input" placeholder="email(可选) 接收证书密码或请记住日期和姓名" />
    </p>

    <p class="row">
      <input type="text" name="special" size="20" maxlength="9" id="special_input" placeholder="备注(可选) 比如以前参加过&#32418;小兵&#32418;卫兵等" />
    </p>

    <p class="submit">
      <input type="hidden" name="act" value="提交">
      <input type="submit" value="提交到大纪元退党网">
    </p>

	<div class="row"><div class="content">
	&#24744;&#21487;&#33021;&#35828;&#25105;&#20063;&#30693;&#36947;&#23427;&#19981;&#22909;&#65292;&#24605;&#24819;&#20013;&#26089;<j3></j3>&#36864;<nmdvo4></nmdvo4>&#20102;&#25110;&#24050;&#36229;&#40836;&#12290;&#20294;&#37027;&#37117;&#19981;&#31639;&#25968;&#65292;&#22240;&#20026;&#22312;&#37027;&#20010;&#34880;&#26071;&#21069;&#38754;&#23545;&#22825;&#21457;&#27602;&#35475;&#26102;&#65292;&#26159;&#35828;&#35201;&#25226;&#29983;&#21629;&#21644;&#19968;&#20999;&#37117;&#36129;&#29486;&#32473;<tu3></tu3>&#37034;<wy6></wy6><k4></k4>&#20826;<x3></x3>&#65292;&#25152;&#20197;&#21482;&#26377;&#37319;&#21462;&#20844;&#24320;&#30340;&#24418;&#24335;&#65288;&#21487;&#29992;&#21270;&#21517;&#65289;&#12289;&#26377;&#34892;&#20026;&#30340;&#34920;&#31034;&#65292;&#25165;&#33021;&#38500;&#25481;&#36825;&#20040;&#22823;&#30340;&#27602;&#35475;&#65292;&#25165;&#33021;&#22312;&#22825;<sqnl9></sqnl9>&#28781;<sgpt4></sgpt4>&#20013;<ggg4></ggg4>&#20849;<cfy7></cfy7>&#30340;&#26102;&#20505;&#20445;&#24179;&#23433;&#65281;
	</div></div>
</fieldset>
</form>

<audio id="aud">您的浏览器不支持 audio 标签</audio>
<?php
if(!isset($_COOKIE[COOKIE_COUNTER])) echo '<img src="?'.COOKIE_COUNTER.'=1" width="0" height="0" style="display:none" />';
?>
</body>
</html>

<script type="text/javascript">domReady();</script>
