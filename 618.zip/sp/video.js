var items=new Array(), inited=false;

$(document).ready(function(){
	init();
});

function getFullUrl(base, url){
	if(!base || !url){
		return url;
	}else if(url.indexOf('://')!==-1){
		return url;
	}else if(url.substr(0,1)=='/'){
		var x=base.indexOf('/',8);
		if(x!==-1) base=base.substr(0,x);
		return base + url;
	}else{
		if(!base.match(/\/$/)) base+='/';
		return base + url;
	}
}

function init(){
	if(inited) return; else inited=true;
	$('#tabs-content').html(d());

	var t = $('#tabs a');
	var c = $('#tabs-content ul');
	t.click(function(){
		var i = $(this).index();
		t.removeClass('cur');
		$(this).addClass('cur');
		c.removeClass('cur');
		c.eq(i).addClass('cur');
		c.eq(i).find('img').each(function(){
			$(this).attr('src',$(this).attr('rel'));
		});
		return false;
	});

	$('#tabs-content ul a').click(function(){
		$('#tabs-content ul a.cur').removeClass('cur');
		$(this).addClass('cur');
		var x=$(this).attr('rel');
		loadVideo(x);
		$('#myvideo_title').text(items[x].title);
		return false;
	});

	jwplayer('myvideo').setup({
		title: items[0].title,
		image: coverImage ? getFullUrl(imagePath, coverImage) : items[0].image,
		file: items[0].file,
		width: '600',
		height: '400',
		primary: 'html5',
		flashplayer: 'images/jwplayer.flash.swf',
		fallback: false,
		allowscriptaccess: 'always',
		autostart: false,
		analytics: {enabled:false, cookies:false}
	});
	$('#myvideo_title').text(items[0].title);
	
	//$('#tabs-content ul a:first').click();
}

function loadVideo(x) {
	jwplayer().load([ items[x] ]);
	jwplayer().play();
}

String.prototype.rot13 = function(){
	return this.replace(/[a-zA-Z]/g, function(c){
		return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26);
	});
};

function d(){
	var s=$.trim($('#content2').text());
	s=s.rot13();
	s=s.replace(/\//g, '%'); 
	s=decodeURIComponent(s);
	if(!s) return;

	var x=0;
	var arr=s.split('\n\n');
	var html=new Array();
	for(var i=0; i<arr.length; i++){
		html.push('<ul class="item-list'+(i==0?' cur':'')+'">');
		var s=$.trim(arr[i]);
		if(s){
			var arr2=s.split('\n');
			for(var j=0; j<arr2.length; j++){
				var s=$.trim(arr2[j]);
				if(s){
					var line=s.split('|',3);
					var item={
						title: line[2],
						image: getFullUrl(imagePath, line[1]),
						file: getFullUrl(videoPath, line[0])
					};
					items[x]=item;
					html.push(
						'<li class="item" title="'+item.title+'"><a href="javascript:" rel="'+x+'">'+
						(i==0 ? '<img src="'+item.image+'" alt="'+item.title+'">' : '<img src="images/loading.gif" rel="'+item.image+'" alt="'+item.title+'">') +
						'<span>'+item.title+'</span></a></li>');
					x++;
				}
			}
		}
		html.push('</ul>');
	}
	return html.join('');
}