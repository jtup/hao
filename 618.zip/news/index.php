<?php
define('APP_CHARSET', 'GBK');
define('CACHE_EXPIRE', 1800); //缓存有效期(单位：秒)
define('USERAGENT_PC', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)');
define('USERAGENT_MOBILE', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Mobile');
define('DEFAULT_ANCHOR_PATTERN', '#<a [^>]*?\bhref\s*=\s*[\'"](?P<link>[^\'">]+)[\'"][^>]*>(?P<text>[^<>]+)</a>#');
define('DEFAULT_LIMIT', 15); //默认采集条数
define('NOW', time());
define('TEMPDIR', dirname(__FILE__));

require('config.inc.php');
require('http.inc.php');
require('global.inc.php');

if(empty($debug)){
	error_reporting(0);
}else{
	error_reporting(E_ALL);
	@ini_set('display_errors', 1);
}

if(IS_GAE){
	$memcache = new Memcache;
	$config = $memcache->get('news_config');
	if(empty($config)) $config = unserialize(file_get_contents('gs://'.CLOUD_STORAGE_BUCKET.'/news_config.txt'));
}elseif(file_exists('~config.txt')){
	$config = unserialize(file_get_contents('~config.txt'));
}
if(empty($config)){
	$config = $default_config;
}

$configs = array(
	array(
		'title' => '网站公告',
		'url' => null,
		'text' => $config['notice'],
	),

	array(
		'title' => '聚缘阁代理论坛',
		'url' => 'http://bbs.juyuange.org/',
		'more' => '{bbs_server}',
		'start' => '普通主题</div>',
		'end' => '<div class="footer">',
		'collect' => '#<a href="[^"<>]+" target="_blank" class="grey">[^<>]+</a>\s+<a href="[^"<>]+" class="subject_link[^"<>]+">[^<>]+</a>#s',
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '大纪元 ● 大陆新闻',
		'url' => 'http://cn.epochtimes.com/gb/nsc413.htm',
		'start' => ' leading-news-list ',
		'end' => '</ul>',
		'pattern' => '#\bhref\s*=\s*[\'"](?P<link>[^">]+)[\'"][^>]*>(?P<text>.*?)</a>#s',
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '新唐人 ● 视频新闻',
		'url' => 'http://cn.ntdtv.com/xtr/gb/prog204.html',
		'start' => '',
		'end' => '',
		'pattern' => '#<a .*?\bhref\s*=\s*[\'"](?P<link>[^">]+)[\'"][^>]*>(?P<text>[^<>]+?)<small class="vid"></small></a>#',
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '阿波罗网 ● 推荐新闻',
		'url' => 'http://www.aboluowang.com/index.html',
		'start' => '#<div id="?tabbing1#',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '看中国网 ● 今日看点',
		'url' => 'https://www.secretchina.com/',
		'start' => '#<div id="today">.*?<ul>|今日看点 更多\'>\s*更多</a>#s',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '一月新闻排行',
		'url' => 'http://wujieliulan.com/',
		'start' => 'id="tabpage_3">',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '明慧要闻',
		'url' => 'http://wujieliulan.com/',
		'more' => 'http://www.minghui.org/',
		'start' => '<h2>明慧要闻</h2>',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '动态网 ● 网站指南',
		'url' => 'http://dongtaiwang.com/loc/phome.php',
		'start' => '<div id="title">动态网网站指南</div>',
		'end' => '<!-- end of center column -->',
		'pattern' => null,
		'header' => '<style type="text/css">#block_{index} .block{} #title_sub{padding:8px 0 1px 0px;font-weight:normal;color:#FF6600;} #ntdtv_player_info{display:none;}</style>',
	),
);

$http_config = array('read_cache'=>false, 'connect_timeout'=>10, 'read_timeout'=>45);
if(!empty($proxy)) $http_config['proxy']=$proxy;
$colors = explode(',', trim($config['colors'],','));

$servers = explode(',', trim($config['servers'],','));
$server = empty($servers) ? '' : $servers[array_rand($servers)];
if($server){
	$server=trim($server,'/');
	if(strpos($server,'://')===false) $server='http://'.$server;
}

$bbs_servers = explode(',', trim($config['bbs_servers'],','));
$bbs_server = empty($bbs_servers) ? '' : $bbs_servers[array_rand($bbs_servers)];
if($bbs_server){
	$bbs_server=trim($bbs_server,'/');
	if(strpos($bbs_server,'://')===false) $bbs_server='http://'.$bbs_server;
}

//读取缓存
$caches = array();
$cacheFile = "~cache.htm";
if(CACHE_EXPIRE>0 && IS_GAE){
	$memcache = new Memcache;
	$caches = $memcache->get('cache');
}else if(CACHE_EXPIRE>0 && file_exists($cacheFile)){
	$caches = unserialize(file_get_contents($cacheFile));
}

if(empty($caches) || !is_array($caches) || @$_GET['cache']=='0') {
	$caches = array();
}

//从缓存或者从远程采集数据
$requests = array();
$htmls = array();
$body = '';
$nav = array();
$index = -1;
$changed = false;
foreach($configs as $k=>$v){
	if(empty($v['url']) && empty($v['text'])){
		unset($v[$k]);
	}
}
foreach($configs as $v){
	$index++;
	$url = $v['url'];
	if($url) {
		$cacheKey = $url.'#'.$v['title'];
		$remoteUrl = Url::create($url);
		if(!$remoteUrl || !in_array($remoteUrl->scheme,array('http','https'))){
			continue;
		}
	}else{
		continue;
	}

	if(!empty($v['text'])){
		$block = "<div class=\"block text\">{$v['text']}</div>";
	}else if(isset($caches[$cacheKey]) && NOW-$caches[$cacheKey]['time']<CACHE_EXPIRE && $caches[$cacheKey]['hash']==crc32(serialize($v))){
		$block = $caches[$cacheKey]['block'];
	}else{
		//下载并解析
		$block = '';
		if(isset($htmls[$url])){
			$html = $htmls[$url];
		}else{
			$start = microtime(true);
			$html = Http::getHtml($url, isset($v['useragent'])?$v['useragent']:USERAGENT_PC, APP_CHARSET, false, $http_config);
			$htmls[$url] = $html;
			$requests[$url] = microtime(true) - $start;
			if(stripos($html, '</a>')===false){
				$block = '<ul class="list"><li>'.$last_http_error.'</li></ul>';
			}
		}

		if(isset($v['collect'])){
			$rows = get_between_links($html, $v['start'], $v['end'], $v['collect'], $remoteUrl);
			if(is_array($rows)){
				$block .= '<ul class="list list-collect">';
				foreach($rows as $k=>$row){
					$s = str_replace($remoteUrl->home, '{bbs_server}', $row[0]);
					$s = str_replace('thread-new">', 'thread-new" target="_blank">', $s);
					$s = preg_replace('#\s+#s', ' ', $s);
					$block .= "<li>$s</li>\n";
				}
				$block .= '</ul>';
				$caches[$cacheKey] = array('time'=>NOW, 'block'=>$block, 'hash'=>crc32(serialize($v)));
				$changed = true;
			}
		}else{
			$rows = get_between_links($html, $v['start'], $v['end'], $v['pattern'], $remoteUrl);
			if(is_string($rows)){
				$block .= "<div class=\"block\">{$rows}</div>";
				$caches[$cacheKey] = array('time'=>NOW, 'block'=>$block, 'hash'=>crc32(serialize($v)));
				$changed = true;
			}else if(is_array($rows)){
				$block .= '<ul class="list list-pattern">';
				foreach($rows as $k=>$row){
					if($k>=$v['limit']) break;
					$text = trim(str_replace('&nbsp;','',strip_tags($row['text'],'<font><span>')));
					$block .= '<li><a href="' . encrypt_url($row['link'], $remoteUrl) . '" target="_blank">' . $text . '</a></li>';
				}
				$block .= '</ul>';
				$caches[$cacheKey] = array('time'=>NOW, 'block'=>$block, 'hash'=>crc32(serialize($v)));
				$changed = true;
			}
		}

		if(!$block){
			$block = '<ul class="list"><li>暂无内容</li></ul>';
		}
	}

	$more = !empty($v['more']) ? $v['more'] : $url;
	if(substr($more,0,1)!='{' || !$bbs_server) $more = encrypt_url($more);

	$body .=
		(!empty($v['header']) ? str_replace('{index}', $index, $v['header']) : '') .
		'<div id="block_'.$index.'"><h2 style="background-color:'.$colors[$index % count($colors)].'">'.
		($url ? "<a href='{$more}' target='_blank'>更多&gt;&gt;</a>" : '').
		$v['title'] .
		'</h2>' . $block . '</div>';
}

$body = str_replace(array('（图）','(图)','(组图)','(图集)'), '<span class=tu>(图)</span>', $body);

//写入缓存
if(CACHE_EXPIRE>0 && $changed){
	if(IS_GAE){
		$memcache->set('cache', $caches);
	}else{
		file_put_contents($cacheFile, serialize($caches), LOCK_EX);
	}
}

//底部
if(!empty($config['foot'])){
	$foot = $config['foot'];
	while(strpos($foot,'<h2>')!==false){
		$index++;
		$foot = str_replace_once('<h2>', '<h2 style="background-color:'.$colors[$index % count($colors)].'">', $foot);
	}
	$body .= $foot;
}

//生成
$nav = str_replace('{server}', $server, implode('',$nav));
$nav = str_encode_s($nav);
$body = str_replace('{server}', $server, $body);
$body = str_replace('{bbs_server}', $bbs_server, $body);
$body = str_encode_s($body);
$css = css();
$title = str_encode_s($config['title']);
$plaintitle = strip_tags($title);

//输出
header('Content-Type: text/html; charset='.APP_CHARSET);
// header('Cache-Control: public, max-age=86400');
// header('Last-Modified: '.gmtDate(TIME));
// header('Expires: '.gmtDate("+1 day"));
// header('ETag: '.substr(md5($body),8,16));

$charset = APP_CHARSET;
echo <<<EOF
<!DOCTYPE html><html><head><meta charset="{$charset}"><title>{$plaintitle}</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<script type="text/javascript">String.prototype.rot13=function(){return this.replace(/[a-zA-Z]/g,function(c){return String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26);});};
function d(s){if(!s)return '';var k=new RegExp('\\\\'+s.charAt(s.length-1),"g");s=s.substring(0,s.length-1);s=s.replace(k,'%');return decodeURIComponent(s.rot13());}
</script>
<!--link rel="stylesheet" type="text/css" href="style.css"/-->
<style type="text/css">$css</style>
</head><body>
<a name="top"></a>
<h1>{$title}</h1>
<!--ul class="nav">{$nav}<div class="clear"></div></ul><div class="clear"-->
<div class="sep"></div>
{$body}
<div class="gotop"><a href="#top">返回顶部</a></div>
</body></html>
EOF;
exit;



/**
 * 截取起止标记之间的内容
 * @param string $content
 * @param string $start
 * @param string $end
 * @param string $pattern
 * @return array
 */
function get_between_links($content, $start, $end, $pattern, $remoteUrl){
	if(!$content || (!$start && !$end && !$pattern))
		return $content;

	//把起始标记替换为简单的占位符
	if(!empty($start)){
		if(($x=stripos($content,$start)) && ($x!==false)){
			$content = substr($content, $x+strlen($start));
		}else if($start{0}=='#' && preg_match($start, $content, $match, PREG_OFFSET_CAPTURE)){
			$content = substr($content, $match[0][1]+strlen($match[0][0]));
		}else{
			return false;
		}
	}

	//把结束标记替换为简单的占位符
	if(!empty($end)){
		if(($x=stripos($content,$end)) && ($x!==false)){
			$content = substr($content, 0, $x-1);
		}else if($end{0}=='#' && preg_match($end, $content, $match, PREG_OFFSET_CAPTURE)){
			$content = substr($content, 0, $match[0][1]-1);
		}else{
			return false;
		}
	}

	//提取$pattern
	if(!empty($pattern)){
		if(preg_match_all($pattern, $content, $matches, PREG_SET_ORDER)){
			return $matches;
		}
	}else{
		//删除脚本和注释
		$content = preg_replace(array('#<!--.*?-->#s', '#<script[\s>].*?</script>#s', '#<object\s.*?</object>#s'), '', $content);
		//加密连接
		$links = array();
		if(preg_match_all(DEFAULT_ANCHOR_PATTERN, $content, $matches, PREG_SET_ORDER)){
			foreach($matches as $match){
				$links[] = $match['link'];
			}
		}
		if(!empty($links)){
			$links = array_unique($links);
			rsort($links);
			$search = $replace = array();
			foreach($links as $link){
				$search[] = $link;
				$replace[] = encrypt_url($link, $remoteUrl);
			}
			if(!empty($search)){
				$content = str_replace($search, $replace, $content);
			}
		}
		return $content;
	}
}

/**
 * 加密网址
 */
function encrypt_url($url, $remoteUrl=null){
	if(stripos($url,'http://')===false && stripos($url,'https://')===false && $remoteUrl){
		$url = $remoteUrl->getFullUrl($url, true);
	}

	if(strpos($url, 'http://cn.epochtimes.com/')===0){
		$url = preg_replace('#^(http://cn\.epochtimes\.com/(?:gb|b5)/)\w+\.htm\?p=\w+\#\w+-(\d+)-(\d+)-(\d+)-(\d+)$#', '$1$2/$3/$4/n$5.htm', $url);
	}

	if(strpos($url, 'http://www.secretchina.com/')===0){
		$url = preg_replace('#^(http://www\.secretchina\.com)/topic/\d+\.html\?nid=(\d+)&title=.*$#', '$1/node/$2', $url);
	}

	//加密url
	return '{server}' . encrypt_url_2nd($url);
}

/**
 * 网页编码（防触墙），可以使用下边的javascript函数解密
 function d(s){
 if(!s)return '';
 var k=new RegExp('\\\\'+s.charAt(s.length-1),"g");
 s=s.substring(0,s.length-1);
 s=s.replace(k,'%');
 return decodeURIComponent(s.rot13());
 }
 */
function str_encode_s($str){
	$str = preg_replace('#\s+#s', ' ', $str);

	//	 $chars = '!@#&=:;,';
	//	 $key = substr($chars,rand(0,strlen($chars)-1),1);
	//	 if(APP_CHARSET!='UTF-8') $str = mb_convert_encoding($str, 'UTF-8', APP_CHARSET);
	//	 $str = strtr(str_rot13(rawurlencode($str)),'%',$key);
	//	 $str = $str.$key;
	//	 $str = '<script type="text/javascript">document.write(d("'.$str.'"));</script>';

	return mb_convert_encoding($str, 'html-entities', APP_CHARSET);
}

function css(){
return <<<EOF
*{margin:0; padding:0;}
html, body {height:100%;}
img{border:0; vertical-align:middle;}
a {color:#5f7b98;text-decoration:none}
a:hover {color:red;}
li{list-style-type:none;}
li a:visited {color:#5f7b99}
.clear{clear:both}

h1{color: #333;font-size:25px;height:40px;line-height:40px;text-align: center;background-image: linear-gradient(#ffffff, #f9f9f9);-webkit-box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.15);}
.nav{background-image: linear-gradient(#ffffff, #f9f9f9);-webkit-box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.15);border-bottom: 1px solid #D1D1D1; margin:5px;}
.nav li{width:100px; float:left; padding:10px 0; text-align:center;}
.nav li a{color: #666;}

.sep{height:20px;}
.title_video{display:inline-block;width:15px;min-height:15px;top:2px;position:relative;left:5px;
background:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPBAMAAADJ+Ih5AAAAA3NCSVQICAjb4U/gAAAAMFBMVEX/////VTL/////Tin/ORD/ZEX/qZf+8O3/clX+RiH+iXH+fWL7yb7+mob/2ND/PBS3VZBnAAAAEHRSTlMA////////////////////wFCLQwAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDIvMTgvMTf26VP0AAAAf0lEQVQImWNgYCjbsfcBAxCoSRoKWxcwMDDtFJ0sKBzOwMA78dtLR0ErBobHgm7qLYbCBxguC7opqU0RXMDQCGQoVRg2MASCGEorAyAiaoIBYDV6IUA1h4GMKx+BurgN/6g6ClozMLAHS9gLCosD7aqQNBSUKADZeio06gADAwAiESEtFDulyQAAAABJRU5ErkJggg==") no-repeat left center;}
.tu{color:#f09; font-size:initial !important; margin-left:5px;}

h2 {font-size:20px;	padding:0 10px;	height:40px;line-height:40px;color:#fff; margin:5px; -webkit-box-shadow: 3px 3px 3px 0 #CCC;}
h2 a{float: right;font-size: 14px;color:#FFF; display:block; width:55px;}
.list {padding:0 10px; margin:5px;}
.list li {overflow:hidden; height:40px; line-height:40px; -webkit-box-sizing:border-box;border-bottom:1px #e2e4e8 dotted;background:transparent url('data:image/gif;base64,R0lGODlhDgAYAIAAAKqqqv///yH5BAEAAAEALAAAAAAOABgAAAIrDBCpa4e83IFRUiXfzTfx/m0WOIpO15zmRIWMW6kQjJWvHbMzXsu7LkIFCgA7') right center no-repeat;padding-right:20px;}
.list-pattern li a{display:block;padding-left:25px;background:transparent url('data:image/gif;base64,R0lGODlhDgAOAIABAMzMzP///yH5BAEAAAEALAAAAAAOAA4AAAIPDI55pu0Po5y02otzYzEUADs=') left 14px no-repeat;}

.block{padding:5px 10px;line-height:25px;}

.bg_brown{background:#ce4b27;}
.bg_navy{background:#5b3ab6;}
.bg_purple{background:#a300aa;}
.bg_darkgreen{background:#009600;}
.bg_highland{background:#0093a8;}
.bg_orange{background:#e88a05;}
.bg_lightblue{background:#3498db;}
.bg_lightgreen{background:#6db51c;}
.bg_red{background:#b51c44;}

.gotop{margin:10px 0;height:40px;line-height:40px;background: #b8c0c8;color: #fff;text-align: center;}
.gotop a{color: #fff;}
EOF;
}