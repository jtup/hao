<?php
//在当前google app里所申请的Cloud Storage的名称（在普通PHP空间上，此设置无效）
define('CLOUD_STORAGE_BUCKET', 'juyuange-new.appspot.com');

//管理员密码
define('PASSWORD', '123456.');

//=========================================================================
// 以下设置是安装时的默认设置，
// 这些设置将在admin.php里被永久性的改变，
// 在gae里是保存在上边的CloudStorage里，在普通空间里是保存在~config.txt里
//=========================================================================

//不要修改这个
define('IS_GAE', isset($_SERVER['APPLICATION_ID']));

$default_config = array(
    //网页标题（支持html标签）
    'title' => '每日精选新闻',

    //从bbs.juyuange.org里采集的普通主题里的链接的域名（可以只是域名，也可以是 http://域名，可以是1个或者是半角逗号分隔的多个域名，多个域名时将会被随机使用）
    'bbs_servers' => '',

    //采集结果里的链接的域名（可以只是域名，也可以是 http://域名，可以是1个或者是半角逗号分隔的多个域名，多个域名时将会被随机使用）
    'servers' => 'http://juyuange-new.appspot.com/',

    //标题栏的背景颜色（多个颜色之间用半角逗号分隔，可以是颜色名称，也可以是类似 #CCCCCC 这样的颜色值）
    'colors' => 'lightblue,lightgreen,orange,navy,purple,darkgreen,brown',

    //网站公告（如果需要输入多条，请输入html网页格式，其中的{server}将会被替换为$servers里的值）
    'notice' => '',

    //网站底部内容（支持html标签，也可以使用以下两个模板）
    //<div><h2>标题</h2><ul class="list"><li>条目</li></ul></div>
    //<div><h2>标题</h2><div class="block text">内容</div></div>
    'foot' => '',
);
